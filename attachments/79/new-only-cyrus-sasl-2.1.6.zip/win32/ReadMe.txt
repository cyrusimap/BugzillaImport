Compiling CMU SASL v2 on Windows.

Configuration before compilation:

1). Define DBDIR environment variable that point to the directory with SleepyCat
    libraries and include files.
2). In order to get privacy protection in DIGEST-MD5, you MUST define DESLIB environment variable.


Configuration before running an application:

1). Create the following registry key:
     HKLM\\SOFTWARE\\Carnegie Mellon\\Project Cyrus\\SASL Library\\SearchPath
   
    This key contains a ; separated list of directories where to search for plugins
    (so basically it has the same format as Windows PATH environment variable).


ToDo List:

1). Cleanup warnings, especially: 
     warning C4018: '<' : signed/unsigned mismatch;
     warning C4090: 'function' : different 'const' qualifiers.
2). Convert all functions exported by DLLs to have WINAPI calling convention, as usually on Windows.
3). Add support for native IPv6 support on Windows XP.
4). Compile KerberosV4 and GSSAPI.
5). Build SRP plugin on Windows and the rest of sasldb utilities.
6). Port saslauthd to Windows?


Known Bugs:

In windlopen.c:
 Quoted paths?
 Windows stat() fails when the directory name contains trailing slash
 (unless the name is a root directory, in which case it MUST have trailing slash).
In common.c:
 sasl_getplugindir is returning allocated memory, so there is a small memory leak
 on each call.


Not tested:
 inet_aton() emulation in getaddrinfo.c
 REG_EXPAND_SZ, REG_MULTI_SZ registry types in sasl_getplugindir() [lib/common.c]


Open Issues:
 SASLv1 was loading plugins from registry. SASLv2 was changed to use registry only
 to store the list of directories where to search for plugins.


FAQ:

1). Q: When linking saslpwd and other applications I am getting something like the following:

LIBCMT.lib(osfinfo.obj) : error LNK2005: __get_osfhandle already defined in MSVCRT.lib(MSVCRT.dll)
LIBCMT.lib(osfinfo.obj) : error LNK2005: __open_osfhandle already defined in MSVCRT.lib(MSVCRT.dll)
LIBCMT.lib(lseek.obj) : error LNK2005: __lseek already defined in MSVCRT.lib(MSVCRT.dll)
LIBCMT.lib(dosmap.obj) : error LNK2005: __errno already defined in MSVCRT.lib(MSVCRT.dll)
LIBCMT.lib(crt0dat.obj) : error LNK2005: _exit already defined in MSVCRT.lib(MSVCRT.dll)
...

A: All libraries that are used to link a final application MUST agree on code generation
   mode. Right click on the project, select "Settings", than "C/C++" tab, select
   "Category" - Code Generation, than select "Use run-time library": "Multithreaded DLL"
   (or whatever you want to use).
