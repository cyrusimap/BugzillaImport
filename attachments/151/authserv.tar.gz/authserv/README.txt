Third-party Authentication Sample Code for Sun ONE Messaging Server MMP
-----------------------------------------------------------------------

This package includes sample code which implements a standalone
thread-pool based authentication server suitable for use with the
Sun ONE Messaging Server Messaging Multiplexor (MMP).

The protocol documented in the file "authserver.txt" is a fully
supported interface designed to integrate third-party authentication
services with the MMP.  The Sun ONE Messaging Server product team is
committed to fixing bugs in our client implementation of this protocol
in the MMP.

The programmer who wrote this sample code put some effort into making
it largely suitable for a production environment.  However, the
Sun ONE Messaging Server product team will not provide support or
bugfixes for this sample code.

MANIFEST
--------
README.txt       This file

authserver.txt   Supported Protocol Specification

Makefile         Use make to build the sample code

authserv.c       The core thread-pool protocol server implementation

authserv.h       The API called by authserv.c to authenticate users

sample.c         A very simple sample third-party authentication
                 module.  Third-parties should edit or replace this
		 module to provide authentication services.
