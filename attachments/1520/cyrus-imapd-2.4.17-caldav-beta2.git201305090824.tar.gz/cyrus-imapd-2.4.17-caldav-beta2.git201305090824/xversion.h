/* cyrus-imapd 2.4.17-caldav-beta2.git201305090824 */
#define _CYRUS_VERSION "git2.4.17-caldav-beta2+0"
#define CYRUS_GITVERSION "bd236f6c 2013-05-0"
