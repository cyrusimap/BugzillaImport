--- sieve/script.h.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/script.h	2011-01-20 18:06:22.000000000 +0000
@@ -61,6 +61,7 @@
     struct sieve_support {
 	int fileinto       : 1;
 	int reject         : 1;
+	int ereject        : 1;
 	int envelope       : 1;
 	int body           : 1;
 	int vacation       : 1;
