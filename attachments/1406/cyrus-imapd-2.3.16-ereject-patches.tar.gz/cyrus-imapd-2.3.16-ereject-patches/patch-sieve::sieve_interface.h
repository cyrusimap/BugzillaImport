--- sieve/sieve_interface.h.ORIG	2009-11-19 21:52:56.000000000 +0000
+++ sieve/sieve_interface.h	2011-01-20 17:27:53.000000000 +0000
@@ -110,6 +110,10 @@
     const char *msg;
 } sieve_reject_context_t;
 
+typedef struct sieve_ereject_context {
+    const char *msg;
+} sieve_ereject_context_t;
+
 typedef struct sieve_fileinto_context {
     const char *mailbox;
     sieve_imapflags_t *imapflags;
@@ -150,6 +154,7 @@
 int sieve_register_redirect(sieve_interp_t *interp, sieve_callback *f);
 int sieve_register_discard(sieve_interp_t *interp, sieve_callback *f);
 int sieve_register_reject(sieve_interp_t *interp, sieve_callback *f);
+int sieve_register_ereject(sieve_interp_t *interp, sieve_callback *f);
 int sieve_register_fileinto(sieve_interp_t *interp, sieve_callback *f);
 int sieve_register_keep(sieve_interp_t *interp, sieve_callback *f);
 int sieve_register_vacation(sieve_interp_t *interp, sieve_vacation_t *v);
