--- imap/lmtpd.c.ORIG	2009-12-16 02:51:41.000000000 +0000
+++ imap/lmtpd.c	2011-01-21 11:16:17.000000000 +0000
@@ -664,7 +664,7 @@
 		break;
 	    case nosieve:
 		/* this is the only delivery we're attempting for this rcpt */
-		msg_setrcpt_status(msgdata, j, lt->rcpt[i].r);
+		msg_setrcpt_status(msgdata, j, lt->rcpt[i].r, NULL);
 		status[j] = done;
 		break;
 	    case done:
@@ -776,6 +776,7 @@
     mydata.namespace = &lmtpd_namespace;
     mydata.authuser = authuser;
     mydata.authstate = authstate;
+    mydata.status_msg = NULL;
     
     /* loop through each recipient, attempting delivery for each */
     for (n = 0; n < nrcpts; n++) {
@@ -821,16 +822,23 @@
 	    r = run_sieve(user, domain, mailbox, sieve_interp, &mydata);
 	    /* if there was no sieve script, or an error during execution,
 	       r is non-zero and we'll do normal delivery */
+
+            if (r == SIEVE_EREJECT) {
+                r = IMAP_CUSTOM_ERROR;
+            }
+
+	    if (r && r != IMAP_CUSTOM_ERROR) {
+
 #else
 	    r = 1;	/* normal delivery */
+	    if (r) {
 #endif
 
-	    if (r) {
 		r = deliver_local(&mydata, NULL, 0, userbuf, mailbox);
 	    }
 	}
 
-	msg_setrcpt_status(msgdata, n, r);
+	msg_setrcpt_status(msgdata, n, r, mydata.status_msg);
     }
 
     if (dlist) {
