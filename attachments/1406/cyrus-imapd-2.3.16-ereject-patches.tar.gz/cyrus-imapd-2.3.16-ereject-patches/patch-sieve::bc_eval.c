--- sieve/bc_eval.c.ORIG	2009-11-19 21:52:56.000000000 +0000
+++ sieve/bc_eval.c	2011-01-21 11:16:47.000000000 +0000
@@ -1031,6 +1031,16 @@
 
 	    break;
 
+	case B_EREJECT:/*?*/
+	    ip = unwrap_string(bc, ip+1, &data, NULL);
+	    
+	    res = do_ereject(actions, data);
+	
+	    if (res == SIEVE_RUN_ERROR)
+		*errmsg = "EReject can not be used with any other action";  
+
+	    break;
+
 	case B_FILEINTO:/*19*/
 	    copy = ntohl(bc[ip+1].value);
 	    ip+=1;
