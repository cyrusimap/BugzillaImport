--- imap/lmtpengine.c.ORIG	2009-04-23 02:30:32.000000000 +0100
+++ imap/lmtpengine.c	2011-01-21 09:40:41.000000000 +0000
@@ -103,6 +103,7 @@
     char *mailbox;	/* pointer to mailbox part of rcpt -- DO NOT be free */
     int ignorequota;
     int status;
+    char *status_msg;	/* storage for custom status message -- MUST be freed */
 };
 
 struct clientdata {
@@ -169,13 +170,17 @@
 #define roundToK(x)
 #endif /* USING_SNMPGEN */
 
-static void send_lmtp_error(struct protstream *pout, int r)
+static void send_lmtp_error(struct protstream *pout, int r, char *msg)
 {
     switch (r) {
     case 0:
 	prot_printf(pout, "250 2.1.5 Ok\r\n");
 	break;
 
+    case IMAP_CUSTOM_ERROR:
+        prot_printf(pout, "550 5.7.1 %s", msg);
+	break;
+
     case IMAP_IOERROR:
 	prot_printf(pout, "451 4.3.0 System I/O error\r\n");
 	break;
@@ -322,6 +327,7 @@
 	for (i = 0; i < m->rcpt_num; i++) {
 	    if (m->rcpt[i]->all) free(m->rcpt[i]->all);
 	    if (m->rcpt[i]->rcpt) free(m->rcpt[i]->rcpt);
+	    if (m->rcpt[i]->status_msg) free(m->rcpt[i]->status_msg);
 	    free(m->rcpt[i]);
 	}
 	free(m->rcpt);
@@ -377,10 +383,12 @@
 
 /* set a recipient status; 'r' should be an IMAP error code that will be
    translated into an LMTP status code */
-void msg_setrcpt_status(message_data_t *m, int rcpt_num, int r)
+void msg_setrcpt_status(message_data_t *m, int rcpt_num, int r, char *msg)
 {
     assert(0 <= rcpt_num && rcpt_num < m->rcpt_num);
     m->rcpt[rcpt_num]->status = r;
+    
+    m->rcpt[rcpt_num]->status_msg = msg;
 }
 
 void *msg_getrock(message_data_t *m)
@@ -764,7 +772,7 @@
 	    func->removespool(m);
 	}
 	while (nrcpts--) {
-	    send_lmtp_error(cd->pout, r);
+	    send_lmtp_error(cd->pout, r, NULL);
 	}
 	return r;
     }
@@ -822,6 +830,8 @@
 
     assert(addr != NULL && msg != NULL);
 
+    ret->status_msg = NULL;
+
     if (*addr == '<') addr++;
     dest = rcpt = addr;
     
@@ -1310,7 +1320,7 @@
 		r = func->deliver(msg, msg->authuser, msg->authstate);
 		for (j = 0; j < msg->rcpt_num; j++) {
 		    if (!msg->rcpt[j]->status) delivered++;
-		    send_lmtp_error(pout, msg->rcpt[j]->status);
+		    send_lmtp_error(pout, msg->rcpt[j]->status, msg->rcpt[j]->status_msg);
 		}
 
 		snmp_increment(mtaTransmittedMessages, delivered);
@@ -1534,7 +1544,7 @@
 				      msg);
 		if (rcpt) free(rcpt); /* malloc'd in parseaddr() */
 		if (r) {
-		    send_lmtp_error(pout, r);
+		    send_lmtp_error(pout, r, NULL);
 		    continue;
 		}
 		msg->rcpt_num++;
