--- sieve/bc_generate.c.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/bc_generate.c	2011-01-20 17:57:55.000000000 +0000
@@ -536,6 +536,13 @@
 		retval->data[codep++].len = strlen(c->u.str);
 		retval->data[codep++].str = c->u.str;
 		break;
+	    case EREJCT:
+		/* EREJECT (STRING: len + dataptr) */
+		if(!atleast(retval,codep+3)) return -1;
+		retval->data[codep++].op = B_EREJECT;
+		retval->data[codep++].len = strlen(c->u.str);
+		retval->data[codep++].str = c->u.str;
+		break;
 	    case FILEINTO:
 		/* FILEINTO
 		   VALUE copy
