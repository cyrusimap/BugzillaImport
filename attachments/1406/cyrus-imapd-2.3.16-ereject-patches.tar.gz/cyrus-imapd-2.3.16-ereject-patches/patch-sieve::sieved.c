--- sieve/sieved.c.ORIG	2009-03-25 23:58:05.000000000 +0000
+++ sieve/sieved.c	2011-01-20 17:40:37.000000000 +0000
@@ -378,6 +378,11 @@
 	    printf("REJECT {%d}%s\n", len, data);
 	    break;
 
+	case B_EREJECT:/*?*/
+	    i = unwrap_string(d, i, &data, &len);
+	    printf("EREJECT {%d}%s\n", len, data);
+	    break;
+
 	case B_FILEINTO: /*19*/
 	    copy = ntohl(d[i++].value);
 	case B_FILEINTO_ORIG: /*4*/
