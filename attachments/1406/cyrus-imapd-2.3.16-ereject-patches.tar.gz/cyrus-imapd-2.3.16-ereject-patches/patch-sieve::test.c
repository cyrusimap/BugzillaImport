--- sieve/test.c.ORIG	2009-03-31 05:11:30.000000000 +0100
+++ sieve/test.c	2011-01-21 09:52:12.000000000 +0000
@@ -432,6 +432,18 @@
     return (*force_fail ? SIEVE_FAIL : SIEVE_OK);
 }
 
+int ereject(void *ac, void *ic, void *sc __attribute__((unused)),
+	   void *mc, const char **errmsg __attribute__((unused)))
+{
+    sieve_ereject_context_t *rc = (sieve_ereject_context_t *) ac;
+    message_data_t *m = (message_data_t *) mc;
+    int *force_fail = (int*) ic;
+
+    printf("erejecting message '%s' with '%s'\n", m->name, rc->msg);
+
+    return (*force_fail ? SIEVE_FAIL : SIEVE_EREJECT);
+}
+
 int fileinto(void *ac, void *ic, void *sc __attribute__((unused)),
 	     void *mc, const char **errmsg __attribute__((unused)))
 {
