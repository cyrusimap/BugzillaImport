--- sieve/interp.h.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/interp.h	2011-01-20 17:30:20.000000000 +0000
@@ -50,7 +50,7 @@
 
 struct sieve_interp {
     /* standard callbacks for actions */
-    sieve_callback *redirect, *discard, *reject, *fileinto, *keep;
+    sieve_callback *redirect, *discard, *reject, *ereject, *fileinto, *keep;
     sieve_callback *notify;
     sieve_vacation_t *vacation;
 
