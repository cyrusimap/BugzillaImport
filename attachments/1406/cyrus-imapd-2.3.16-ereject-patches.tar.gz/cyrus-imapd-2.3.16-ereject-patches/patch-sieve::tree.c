--- sieve/tree.c.ORIG	2009-03-25 23:58:54.000000000 +0000
+++ sieve/tree.c	2011-01-20 17:58:52.000000000 +0000
@@ -225,6 +225,7 @@
 	    break;
 
 	case REJCT:
+	case EREJCT:
 	    if (cl->u.str) free(cl->u.str);
 	    break;
 
