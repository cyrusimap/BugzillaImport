--- imap/lmtpstats.h.ORIG	2009-12-21 13:17:55.000000000 +0000
+++ imap/lmtpstats.h	2011-01-20 19:24:03.000000000 +0000
@@ -1,7 +1,7 @@
 
 /* lmtpstats.h -- statistics push interface
 
- * generated automatically from lmtpstats.snmp by snmpgen
+ * generated automatically from ./lmtpstats.snmp by snmpgen
 
  *
 
@@ -68,6 +68,7 @@
 
 typedef enum {
 
+    SIEVE_EREJECT,
     mtaSuccessfulConvertedMessages,
     AUTHENTICATION_YES,
     SIEVE_FILEINTO,
