--- sieve/message.c.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/message.c	2011-01-21 11:16:59.000000000 +0000
@@ -55,6 +55,7 @@
 #include <sys/stat.h>
 #include <fcntl.h>
 #include <string.h>
+#include <syslog.h>
 
 #include "md5global.h"
 #include "md5.h"
@@ -105,6 +106,44 @@
     return 0;
 }
 
+/* ereject message m with message msg
+ *
+ * incompatible with: fileinto, redirect
+ */
+int do_ereject(action_list_t *a, const char *msg)
+{
+    action_list_t *b = NULL;
+
+    /* see if this conflicts with any previous actions taken on this message */
+    while (a != NULL) {
+	b = a;
+	if (a->a == ACTION_FILEINTO ||
+	    a->a == ACTION_KEEP ||
+	    a->a == ACTION_REDIRECT ||
+	    a->a == ACTION_REJECT ||
+	    a->a == ACTION_VACATION ||
+	    a->a == ACTION_SETFLAG ||
+	    a->a == ACTION_ADDFLAG ||
+	    a->a == ACTION_REMOVEFLAG ||
+	    a->a == ACTION_MARK ||
+	    a->a == ACTION_UNMARK
+	    )
+	    return SIEVE_RUN_ERROR;
+	a = a->next;
+    }
+
+    /* add to the action list */
+    a = (action_list_t *) xmalloc(sizeof(action_list_t));
+    if (a == NULL)
+	return SIEVE_NOMEM;
+    a->a = ACTION_EREJECT;
+    a->cancel_keep = 1;
+    a->u.erej.msg = msg;
+    b->next = a;
+    a->next =  NULL;
+    return SIEVE_EREJECT;
+}
+
 /* fileinto message m into mailbox 
  *
  * incompatible with: reject
