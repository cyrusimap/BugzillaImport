--- sieve/sievec.c.ORIG	2009-03-25 23:58:04.000000000 +0000
+++ sieve/sievec.c	2011-01-20 17:38:24.000000000 +0000
@@ -214,6 +214,11 @@
 	syslog(LOG_ERR, "sieve_register_reject() returns %d\n", res);
 	return TIMSIEVE_FAIL;
     }
+    res = sieve_register_ereject(i, (sieve_callback *) &foo);
+    if (res != SIEVE_OK) {
+	syslog(LOG_ERR, "sieve_register_ereject() returns %d\n", res);
+	return TIMSIEVE_FAIL;
+    }
     res = sieve_register_fileinto(i, (sieve_callback *) &foo);
     if (res != SIEVE_OK) {
 	syslog(LOG_ERR, "sieve_register_fileinto() returns %d\n", res);
