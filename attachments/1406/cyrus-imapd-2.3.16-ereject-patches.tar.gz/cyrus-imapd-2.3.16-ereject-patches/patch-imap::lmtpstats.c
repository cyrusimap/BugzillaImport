--- imap/lmtpstats.c.ORIG	2009-12-21 13:17:55.000000000 +0000
+++ imap/lmtpstats.c	2011-01-20 19:24:03.000000000 +0000
@@ -1,5 +1,5 @@
 
-/* lmtpstats.c -- automatically generated from lmtpstats.snmp by snmpgen */
+/* lmtpstats.c -- automatically generated from ./lmtpstats.snmp by snmpgen */
 
 
 
@@ -85,6 +85,7 @@
 
     switch (evt) {
 
+        case SIEVE_EREJECT: return "sieve extended-rejects";
         case mtaSuccessfulConvertedMessages: return "Messages converted because of 8bit foo";
         case AUTHENTICATION_YES: return "Successful authentication of given mechanism";
         case SIEVE_FILEINTO: return "sieve fileintos";
@@ -123,17 +124,18 @@
 
     switch (evt) {
 
+        case SIEVE_EREJECT: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.4"); return buf;
         case mtaSuccessfulConvertedMessages: snprintf(buf,buflen,"1.3.6.1.2.1.28.1.%d.10",varvalue(VARIABLE_MTA)); return buf;
         case AUTHENTICATION_YES: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.2.2.%d.0",varvalue(VARIABLE_AUTH)); return buf;
-        case SIEVE_FILEINTO: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.4"); return buf;
+        case SIEVE_FILEINTO: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.5"); return buf;
         case mtaReceivedVolume: snprintf(buf,buflen,"1.3.6.1.2.1.28.1.%d.4",varvalue(VARIABLE_MTA)); return buf;
-        case SIEVE_VACATION_TOTAL: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.8"); return buf;
+        case SIEVE_VACATION_TOTAL: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.9"); return buf;
         case SIEVE_MESSAGES_PROCESSED: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.0"); return buf;
-        case SIEVE_KEEP: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.5"); return buf;
+        case SIEVE_KEEP: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.6"); return buf;
         case SIEVE_DISCARD: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.2"); return buf;
         case SERVER_NAME_VERSION: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.2.3.0"); return buf;
         case AUTHENTICATION_NO: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.2.2.%d.1",varvalue(VARIABLE_AUTH)); return buf;
-        case SIEVE_VACATION_REPLIED: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.7"); return buf;
+        case SIEVE_VACATION_REPLIED: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.8"); return buf;
         case SIEVE_REJECT: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.3"); return buf;
         case TOTAL_CONNECTIONS: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.2.1.1"); return buf;
         case ACTIVE_CONNECTIONS: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.2.1.2"); return buf;
@@ -141,7 +143,7 @@
         case mtaTransmittedMessages: snprintf(buf,buflen,"1.3.6.1.2.1.28.1.%d.3",varvalue(VARIABLE_MTA)); return buf;
         case SIEVE_REDIRECT: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.1"); return buf;
         case mtaTransmittedVolume: snprintf(buf,buflen,"1.3.6.1.2.1.28.1.%d.6",varvalue(VARIABLE_MTA)); return buf;
-        case SIEVE_NOTIFY: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.6"); return buf;
+        case SIEVE_NOTIFY: snprintf(buf,buflen,"1.3.6.1.4.1.3.2.2.3.3.4.7"); return buf;
         case mtaReceivedMessages: snprintf(buf,buflen,"1.3.6.1.2.1.28.1.%d.1",varvalue(VARIABLE_MTA)); return buf;
         case mtaReceivedRecipients: snprintf(buf,buflen,"1.3.6.1.2.1.28.1.%d.7",varvalue(VARIABLE_MTA)); return buf;
 
