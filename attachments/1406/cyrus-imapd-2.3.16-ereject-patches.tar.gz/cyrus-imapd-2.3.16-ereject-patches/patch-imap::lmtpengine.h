--- imap/lmtpengine.h.ORIG	2009-04-23 18:10:06.000000000 +0100
+++ imap/lmtpengine.h	2011-01-20 19:26:06.000000000 +0000
@@ -96,7 +96,7 @@
 
 /* set a recipient status; 'r' should be an IMAP error code that will be
    translated into an LMTP status code */
-void msg_setrcpt_status(message_data_t *m, int rcpt_num, int r);
+void msg_setrcpt_status(message_data_t *m, int rcpt_num, int r, char *msg);
 
 void *msg_getrock(message_data_t *m);
 void msg_setrock(message_data_t *m, void *rock);
