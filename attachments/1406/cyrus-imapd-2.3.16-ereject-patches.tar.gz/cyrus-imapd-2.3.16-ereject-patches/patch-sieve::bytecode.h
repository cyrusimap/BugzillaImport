--- sieve/bytecode.h.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/bytecode.h	2011-01-20 17:49:41.000000000 +0000
@@ -135,7 +135,9 @@
     B_RETURN,		/* require include */
 
     B_FILEINTO,		/* require fileinto */
-    B_REDIRECT
+    B_REDIRECT,
+
+    B_EREJECT		/* require ereject */
 };
 
 enum bytecode_comps {
