--- sieve/script.c.ORIG	2009-11-19 21:52:56.000000000 +0000
+++ sieve/script.c	2011-01-21 11:17:19.000000000 +0000
@@ -92,6 +92,14 @@
 	} else {
 	    return 0;
 	}
+    } else if (!strcmp("ereject", req)) {
+	if (s->interp.ereject &&
+	    (config_sieve_extensions & IMAP_ENUM_SIEVE_EXTENSIONS_EREJECT)) {
+	    s->support.ereject = 1;
+	    return 1;
+	} else {
+	    return 0;
+	}
     } else if (!strcmp("envelope", req)) {
 	if (s->interp.getenvelope &&
 	    (config_sieve_extensions & IMAP_ENUM_SIEVE_EXTENSIONS_ENVELOPE)) {
@@ -478,6 +486,7 @@
     switch(action)
 	{
 	case ACTION_REJECT: return "Reject";
+	case ACTION_EREJECT: return "EReject";
 	case ACTION_FILEINTO: return "Fileinto";
 	case ACTION_KEEP: return "Keep";
 	case ACTION_REDIRECT: return "Redirect";
@@ -506,6 +515,7 @@
 	case SIEVE_RUN_ERROR: return "Run error";
 	case SIEVE_INTERNAL_ERROR: return "Internal Error";
 	case SIEVE_NOMEM: return "No memory";
+	case SIEVE_EREJECT: return "Sieve extended-reject situation";
 	default: return "Unknown error";
 	}
 
@@ -618,7 +628,8 @@
 			  const char *errmsg
 			  ) 
 {
-   if (ret != SIEVE_OK) {
+
+   if (ret != SIEVE_OK && ret != SIEVE_EREJECT) {
 	if (lastaction == -1) /* we never executed an action */
 	    snprintf(actions_string+strlen(actions_string),
 		     ACTIONS_STRING_LEN-strlen(actions_string),
@@ -665,7 +676,7 @@
       
       }
     
-    if ((ret != SIEVE_OK) && interp->err) {
+    if ((ret != SIEVE_OK && ret != SIEVE_EREJECT) && interp->err) {
 	char buf[1024];
 	if (lastaction == -1) /* we never executed an action */
 	    snprintf(buf, sizeof(buf), "%s", errmsg ? errmsg : sieve_errstr(ret));
@@ -746,6 +757,21 @@
 			 "Rejected with: %s\n", a->u.rej.msg);
 
 	    break;
+	case ACTION_EREJECT:
+	    if (!interp->ereject)
+		return SIEVE_INTERNAL_ERROR;
+	    ret = interp->ereject(&a->u.erej,
+				 interp->interp_context,
+				 script_context,
+				 message_context,
+				 &errmsg);
+	    
+	    if (ret == SIEVE_EREJECT)
+		snprintf(actions_string+strlen(actions_string),
+			 ACTIONS_STRING_LEN-strlen(actions_string), 
+			 "Extended-Rejected with: %s\n", a->u.erej.msg);
+
+	    break;
 	case ACTION_FILEINTO:
 	    if (!interp->fileinto)
 		return SIEVE_INTERNAL_ERROR;
@@ -939,7 +965,8 @@
 			    script_context, message_context,
 			    &imapflags, actions, notify_list, &errmsg);
 
-	if (ret < 0) {
+
+	if (ret < 0 && ret != SIEVE_OK && ret != SIEVE_EREJECT) {
 	    ret = do_sieve_error(SIEVE_RUN_ERROR, interp, &body_cache,
 				 script_context, message_context, &imapflags,
 				 actions, notify_list, lastaction, 0,
