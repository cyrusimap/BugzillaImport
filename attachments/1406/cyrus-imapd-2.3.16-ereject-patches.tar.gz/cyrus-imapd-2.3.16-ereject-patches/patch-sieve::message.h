--- sieve/message.h.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/message.h	2011-01-20 17:32:33.000000000 +0000
@@ -66,7 +66,8 @@
     ACTION_MARK,
     ACTION_UNMARK,
     ACTION_NOTIFY,
-    ACTION_DENOTIFY
+    ACTION_DENOTIFY,
+    ACTION_EREJECT
 } action_t;
 
 /* information */
@@ -82,6 +83,7 @@
     int cancel_keep;
     union {
 	sieve_reject_context_t rej;
+	sieve_ereject_context_t erej;
 	sieve_fileinto_context_t fil;
 	sieve_keep_context_t keep;
 	sieve_redirect_context_t red;
@@ -131,6 +133,7 @@
  * these don't actually perform the actions, they just add it to the
  * action list */
 int do_reject(action_list_t *m, const char *msg);
+int do_ereject(action_list_t *m, const char *msg);
 int do_fileinto(action_list_t *m, const char *mbox, int cancel_keep,
 		sieve_imapflags_t *imapflags);
 int do_redirect(action_list_t *m, const char *addr, int cancel_keep);
