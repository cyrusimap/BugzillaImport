--- sieve/sieve.c.ORIG	2009-12-21 13:17:55.000000000 +0000
+++ sieve/sieve.c	2011-01-20 19:19:47.000000000 +0000
@@ -1,24 +1,23 @@
-/* A Bison parser, made by GNU Bison 2.3.  */
 
-/* Skeleton implementation for Bison's Yacc-like parsers in C
+/* A Bison parser, made by GNU Bison 2.4.1.  */
 
-   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
+/* Skeleton implementation for Bison's Yacc-like parsers in C
+   
+      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
    Free Software Foundation, Inc.
-
-   This program is free software; you can redistribute it and/or modify
+   
+   This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
-   the Free Software Foundation; either version 2, or (at your option)
-   any later version.
-
+   the Free Software Foundation, either version 3 of the License, or
+   (at your option) any later version.
+   
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
-
+   
    You should have received a copy of the GNU General Public License
-   along with this program; if not, write to the Free Software
-   Foundation, Inc., 51 Franklin Street, Fifth Floor,
-   Boston, MA 02110-1301, USA.  */
+   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */
 
 /* As a special exception, you may create a larger work that contains
    part or all of the Bison parser skeleton and distribute that work
@@ -29,7 +28,7 @@
    special exception, which will cause the skeleton and the resulting
    Bison output files to be licensed under the GNU General Public
    License without this special exception.
-
+   
    This special exception was added by the Free Software Foundation in
    version 2.2 of Bison.  */
 
@@ -47,7 +46,7 @@
 #define YYBISON 1
 
 /* Bison version.  */
-#define YYBISON_VERSION "2.3"
+#define YYBISON_VERSION "2.4.1"
 
 /* Skeleton name.  */
 #define YYSKELETON_NAME "yacc.c"
@@ -55,172 +54,21 @@
 /* Pure parsers.  */
 #define YYPURE 0
 
-/* Using locations.  */
-#define YYLSP_NEEDED 0
-
+/* Push parsers.  */
+#define YYPUSH 0
 
+/* Pull parsers.  */
+#define YYPULL 1
 
-/* Tokens.  */
-#ifndef YYTOKENTYPE
-# define YYTOKENTYPE
-   /* Put the tokens into the symbol table, so that GDB and other debuggers
-      know about them.  */
-   enum yytokentype {
-     NUMBER = 258,
-     STRING = 259,
-     IF = 260,
-     ELSIF = 261,
-     ELSE = 262,
-     REJCT = 263,
-     FILEINTO = 264,
-     REDIRECT = 265,
-     KEEP = 266,
-     STOP = 267,
-     DISCARD = 268,
-     VACATION = 269,
-     REQUIRE = 270,
-     SETFLAG = 271,
-     ADDFLAG = 272,
-     REMOVEFLAG = 273,
-     MARK = 274,
-     UNMARK = 275,
-     NOTIFY = 276,
-     DENOTIFY = 277,
-     ANYOF = 278,
-     ALLOF = 279,
-     EXISTS = 280,
-     SFALSE = 281,
-     STRUE = 282,
-     HEADER = 283,
-     NOT = 284,
-     SIZE = 285,
-     ADDRESS = 286,
-     ENVELOPE = 287,
-     BODY = 288,
-     COMPARATOR = 289,
-     IS = 290,
-     CONTAINS = 291,
-     MATCHES = 292,
-     REGEX = 293,
-     COUNT = 294,
-     VALUE = 295,
-     OVER = 296,
-     UNDER = 297,
-     GT = 298,
-     GE = 299,
-     LT = 300,
-     LE = 301,
-     EQ = 302,
-     NE = 303,
-     ALL = 304,
-     LOCALPART = 305,
-     DOMAIN = 306,
-     USER = 307,
-     DETAIL = 308,
-     RAW = 309,
-     TEXT = 310,
-     CONTENT = 311,
-     DAYS = 312,
-     ADDRESSES = 313,
-     SUBJECT = 314,
-     FROM = 315,
-     HANDLE = 316,
-     MIME = 317,
-     METHOD = 318,
-     ID = 319,
-     OPTIONS = 320,
-     LOW = 321,
-     NORMAL = 322,
-     HIGH = 323,
-     ANY = 324,
-     MESSAGE = 325,
-     INCLUDE = 326,
-     PERSONAL = 327,
-     GLOBAL = 328,
-     RETURN = 329,
-     COPY = 330
-   };
-#endif
-/* Tokens.  */
-#define NUMBER 258
-#define STRING 259
-#define IF 260
-#define ELSIF 261
-#define ELSE 262
-#define REJCT 263
-#define FILEINTO 264
-#define REDIRECT 265
-#define KEEP 266
-#define STOP 267
-#define DISCARD 268
-#define VACATION 269
-#define REQUIRE 270
-#define SETFLAG 271
-#define ADDFLAG 272
-#define REMOVEFLAG 273
-#define MARK 274
-#define UNMARK 275
-#define NOTIFY 276
-#define DENOTIFY 277
-#define ANYOF 278
-#define ALLOF 279
-#define EXISTS 280
-#define SFALSE 281
-#define STRUE 282
-#define HEADER 283
-#define NOT 284
-#define SIZE 285
-#define ADDRESS 286
-#define ENVELOPE 287
-#define BODY 288
-#define COMPARATOR 289
-#define IS 290
-#define CONTAINS 291
-#define MATCHES 292
-#define REGEX 293
-#define COUNT 294
-#define VALUE 295
-#define OVER 296
-#define UNDER 297
-#define GT 298
-#define GE 299
-#define LT 300
-#define LE 301
-#define EQ 302
-#define NE 303
-#define ALL 304
-#define LOCALPART 305
-#define DOMAIN 306
-#define USER 307
-#define DETAIL 308
-#define RAW 309
-#define TEXT 310
-#define CONTENT 311
-#define DAYS 312
-#define ADDRESSES 313
-#define SUBJECT 314
-#define FROM 315
-#define HANDLE 316
-#define MIME 317
-#define METHOD 318
-#define ID 319
-#define OPTIONS 320
-#define LOW 321
-#define NORMAL 322
-#define HIGH 323
-#define ANY 324
-#define MESSAGE 325
-#define INCLUDE 326
-#define PERSONAL 327
-#define GLOBAL 328
-#define RETURN 329
-#define COPY 330
-
+/* Using locations.  */
+#define YYLSP_NEEDED 0
 
 
 
 /* Copy the first part of user declarations.  */
-#line 1 "sieve.y"
+
+/* Line 189 of yacc.c  */
+#line 1 "./sieve.y"
 
 /* sieve.y -- sieve parser
  * Larry Greenfield
@@ -388,6 +236,9 @@
 #define YYERROR_VERBOSE /* i want better error messages! */
 
 
+/* Line 189 of yacc.c  */
+#line 241 "y.tab.c"
+
 /* Enabling traces.  */
 #ifndef YYDEBUG
 # define YYDEBUG 0
@@ -406,10 +257,175 @@
 # define YYTOKEN_TABLE 0
 #endif
 
+
+/* Tokens.  */
+#ifndef YYTOKENTYPE
+# define YYTOKENTYPE
+   /* Put the tokens into the symbol table, so that GDB and other debuggers
+      know about them.  */
+   enum yytokentype {
+     NUMBER = 258,
+     STRING = 259,
+     IF = 260,
+     ELSIF = 261,
+     ELSE = 262,
+     REJCT = 263,
+     FILEINTO = 264,
+     REDIRECT = 265,
+     KEEP = 266,
+     STOP = 267,
+     DISCARD = 268,
+     VACATION = 269,
+     REQUIRE = 270,
+     EREJCT = 271,
+     SETFLAG = 272,
+     ADDFLAG = 273,
+     REMOVEFLAG = 274,
+     MARK = 275,
+     UNMARK = 276,
+     NOTIFY = 277,
+     DENOTIFY = 278,
+     ANYOF = 279,
+     ALLOF = 280,
+     EXISTS = 281,
+     SFALSE = 282,
+     STRUE = 283,
+     HEADER = 284,
+     NOT = 285,
+     SIZE = 286,
+     ADDRESS = 287,
+     ENVELOPE = 288,
+     BODY = 289,
+     COMPARATOR = 290,
+     IS = 291,
+     CONTAINS = 292,
+     MATCHES = 293,
+     REGEX = 294,
+     COUNT = 295,
+     VALUE = 296,
+     OVER = 297,
+     UNDER = 298,
+     GT = 299,
+     GE = 300,
+     LT = 301,
+     LE = 302,
+     EQ = 303,
+     NE = 304,
+     ALL = 305,
+     LOCALPART = 306,
+     DOMAIN = 307,
+     USER = 308,
+     DETAIL = 309,
+     RAW = 310,
+     TEXT = 311,
+     CONTENT = 312,
+     DAYS = 313,
+     ADDRESSES = 314,
+     SUBJECT = 315,
+     FROM = 316,
+     HANDLE = 317,
+     MIME = 318,
+     METHOD = 319,
+     ID = 320,
+     OPTIONS = 321,
+     LOW = 322,
+     NORMAL = 323,
+     HIGH = 324,
+     ANY = 325,
+     MESSAGE = 326,
+     INCLUDE = 327,
+     PERSONAL = 328,
+     GLOBAL = 329,
+     RETURN = 330,
+     COPY = 331
+   };
+#endif
+/* Tokens.  */
+#define NUMBER 258
+#define STRING 259
+#define IF 260
+#define ELSIF 261
+#define ELSE 262
+#define REJCT 263
+#define FILEINTO 264
+#define REDIRECT 265
+#define KEEP 266
+#define STOP 267
+#define DISCARD 268
+#define VACATION 269
+#define REQUIRE 270
+#define EREJCT 271
+#define SETFLAG 272
+#define ADDFLAG 273
+#define REMOVEFLAG 274
+#define MARK 275
+#define UNMARK 276
+#define NOTIFY 277
+#define DENOTIFY 278
+#define ANYOF 279
+#define ALLOF 280
+#define EXISTS 281
+#define SFALSE 282
+#define STRUE 283
+#define HEADER 284
+#define NOT 285
+#define SIZE 286
+#define ADDRESS 287
+#define ENVELOPE 288
+#define BODY 289
+#define COMPARATOR 290
+#define IS 291
+#define CONTAINS 292
+#define MATCHES 293
+#define REGEX 294
+#define COUNT 295
+#define VALUE 296
+#define OVER 297
+#define UNDER 298
+#define GT 299
+#define GE 300
+#define LT 301
+#define LE 302
+#define EQ 303
+#define NE 304
+#define ALL 305
+#define LOCALPART 306
+#define DOMAIN 307
+#define USER 308
+#define DETAIL 309
+#define RAW 310
+#define TEXT 311
+#define CONTENT 312
+#define DAYS 313
+#define ADDRESSES 314
+#define SUBJECT 315
+#define FROM 316
+#define HANDLE 317
+#define MIME 318
+#define METHOD 319
+#define ID 320
+#define OPTIONS 321
+#define LOW 322
+#define NORMAL 323
+#define HIGH 324
+#define ANY 325
+#define MESSAGE 326
+#define INCLUDE 327
+#define PERSONAL 328
+#define GLOBAL 329
+#define RETURN 330
+#define COPY 331
+
+
+
+
 #if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
 typedef union YYSTYPE
-#line 168 "sieve.y"
 {
+
+/* Line 214 of yacc.c  */
+#line 168 "./sieve.y"
+
     int nval;
     char *sval;
     stringlist_t *sl;
@@ -422,22 +438,23 @@
     struct btags *btag;
     struct ntags *ntag;
     struct dtags *dtag;
-}
-/* Line 187 of yacc.c.  */
-#line 428 "y.tab.c"
-	YYSTYPE;
+
+
+
+/* Line 214 of yacc.c  */
+#line 446 "y.tab.c"
+} YYSTYPE;
+# define YYSTYPE_IS_TRIVIAL 1
 # define yystype YYSTYPE /* obsolescent; will be withdrawn */
 # define YYSTYPE_IS_DECLARED 1
-# define YYSTYPE_IS_TRIVIAL 1
 #endif
 
 
-
 /* Copy the second part of user declarations.  */
 
 
-/* Line 216 of yacc.c.  */
-#line 441 "y.tab.c"
+/* Line 264 of yacc.c  */
+#line 458 "y.tab.c"
 
 #ifdef short
 # undef short
@@ -512,14 +529,14 @@
 #if (defined __STDC__ || defined __C99__FUNC__ \
      || defined __cplusplus || defined _MSC_VER)
 static int
-YYID (int i)
+YYID (int yyi)
 #else
 static int
-YYID (i)
-    int i;
+YYID (yyi)
+    int yyi;
 #endif
 {
-  return i;
+  return yyi;
 }
 #endif
 
@@ -600,9 +617,9 @@
 /* A type that is properly aligned for any stack member.  */
 union yyalloc
 {
-  yytype_int16 yyss;
-  YYSTYPE yyvs;
-  };
+  yytype_int16 yyss_alloc;
+  YYSTYPE yyvs_alloc;
+};
 
 /* The size of the maximum gap between one aligned stack and the next.  */
 # define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)
@@ -636,12 +653,12 @@
    elements in the stack, and YYPTR gives the new location of the
    stack.  Advance YYPTR to a properly aligned location for the next
    stack.  */
-# define YYSTACK_RELOCATE(Stack)					\
+# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
     do									\
       {									\
 	YYSIZE_T yynewbytes;						\
-	YYCOPY (&yyptr->Stack, Stack, yysize);				\
-	Stack = &yyptr->Stack;						\
+	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
+	Stack = &yyptr->Stack_alloc;					\
 	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
 	yyptr += yynewbytes / sizeof (*yyptr);				\
       }									\
@@ -652,20 +669,20 @@
 /* YYFINAL -- State number of the termination state.  */
 #define YYFINAL  8
 /* YYLAST -- Last index in YYTABLE.  */
-#define YYLAST   248
+#define YYLAST   231
 
 /* YYNTOKENS -- Number of terminals.  */
-#define YYNTOKENS  84
+#define YYNTOKENS  85
 /* YYNNTS -- Number of nonterminals.  */
 #define YYNNTS  28
 /* YYNRULES -- Number of rules.  */
-#define YYNRULES  106
+#define YYNRULES  107
 /* YYNRULES -- Number of states.  */
-#define YYNSTATES  164
+#define YYNSTATES  166
 
 /* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
 #define YYUNDEFTOK  2
-#define YYMAXUTOK   330
+#define YYMAXUTOK   331
 
 #define YYTRANSLATE(YYX)						\
   ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)
@@ -677,15 +694,15 @@
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
-      82,    83,     2,     2,    79,     2,     2,     2,     2,     2,
-       2,     2,     2,     2,     2,     2,     2,     2,     2,    76,
+      83,    84,     2,     2,    80,     2,     2,     2,     2,     2,
+       2,     2,     2,     2,     2,     2,     2,     2,     2,    77,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
-       2,    77,     2,    78,     2,     2,     2,     2,     2,     2,
+       2,    78,     2,    79,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
-       2,     2,     2,    80,     2,    81,     2,     2,     2,     2,
+       2,     2,     2,    81,     2,    82,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
        2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
@@ -706,7 +723,7 @@
       45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
       55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
       65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
-      75
+      75,    76
 };
 
 #if YYDEBUG
@@ -715,68 +732,68 @@
 static const yytype_uint16 yyprhs[] =
 {
        0,     0,     3,     5,     8,     9,    12,    16,    18,    21,
-      24,    29,    32,    33,    38,    41,    44,    48,    52,    54,
-      56,    58,    62,    65,    68,    71,    73,    75,    78,    81,
-      85,    87,    88,    90,    92,    93,    97,   101,   105,   108,
-     112,   113,   116,   120,   124,   126,   128,   130,   131,   135,
-     139,   143,   147,   151,   154,   158,   160,   162,   166,   170,
-     173,   176,   179,   182,   184,   186,   191,   196,   200,   203,
-     207,   209,   211,   213,   214,   217,   220,   224,   228,   229,
-     232,   236,   240,   241,   244,   247,   251,   254,   258,   262,
-     264,   266,   268,   270,   272,   274,   276,   278,   280,   282,
-     284,   286,   288,   289,   291,   295,   297
+      24,    29,    32,    33,    38,    41,    44,    47,    51,    55,
+      57,    59,    61,    65,    68,    71,    74,    76,    78,    81,
+      84,    88,    90,    91,    93,    95,    96,   100,   104,   108,
+     111,   115,   116,   119,   123,   127,   129,   131,   133,   134,
+     138,   142,   146,   150,   154,   157,   161,   163,   165,   169,
+     173,   176,   179,   182,   185,   187,   189,   194,   199,   203,
+     206,   210,   212,   214,   216,   217,   220,   223,   227,   231,
+     232,   235,   239,   243,   244,   247,   250,   254,   257,   261,
+     265,   267,   269,   271,   273,   275,   277,   279,   281,   283,
+     285,   287,   289,   291,   292,   294,   298,   300
 };
 
 /* YYRHS -- A `-1'-separated list of the rules' RHS.  */
 static const yytype_int8 yyrhs[] =
 {
-      85,     0,    -1,    86,    -1,    86,    88,    -1,    -1,    87,
-      86,    -1,    15,    97,    76,    -1,    89,    -1,    89,    88,
-      -1,    91,    76,    -1,     5,   100,    99,    90,    -1,     1,
-      76,    -1,    -1,     6,   100,    99,    90,    -1,     7,    99,
-      -1,     8,     4,    -1,     9,   109,     4,    -1,    10,   109,
-       4,    -1,    11,    -1,    12,    -1,    13,    -1,    14,    96,
-       4,    -1,    16,    97,    -1,    17,    97,    -1,    18,    97,
-      -1,    19,    -1,    20,    -1,    21,    93,    -1,    22,    94,
-      -1,    71,    92,     4,    -1,    74,    -1,    -1,    72,    -1,
-      73,    -1,    -1,    93,    64,     4,    -1,    93,    63,     4,
-      -1,    93,    65,    97,    -1,    93,    95,    -1,    93,    70,
-       4,    -1,    -1,    94,    95,    -1,    94,   106,     4,    -1,
-      94,   107,     4,    -1,    66,    -1,    67,    -1,    68,    -1,
-      -1,    96,    57,     3,    -1,    96,    58,    97,    -1,    96,
-      59,     4,    -1,    96,    60,     4,    -1,    96,    61,     4,
-      -1,    96,    62,    -1,    77,    98,    78,    -1,     4,    -1,
-       4,    -1,    98,    79,     4,    -1,    80,    88,    81,    -1,
-      80,    81,    -1,    23,   110,    -1,    24,   110,    -1,    25,
-      97,    -1,    26,    -1,    27,    -1,    28,   103,    97,    97,
-      -1,   101,   102,    97,    97,    -1,    33,   104,    97,    -1,
-      29,   100,    -1,    30,   108,     3,    -1,     1,    -1,    31,
-      -1,    32,    -1,    -1,   102,   105,    -1,   102,   106,    -1,
-     102,   107,     4,    -1,   102,    34,     4,    -1,    -1,   103,
-     106,    -1,   103,   107,     4,    -1,   103,    34,     4,    -1,
-      -1,   104,    54,    -1,   104,    55,    -1,   104,    56,    97,
-      -1,   104,   106,    -1,   104,   107,     4,    -1,   104,    34,
-       4,    -1,    49,    -1,    50,    -1,    51,    -1,    52,    -1,
-      53,    -1,    35,    -1,    36,    -1,    37,    -1,    38,    -1,
-      39,    -1,    40,    -1,    41,    -1,    42,    -1,    -1,    75,
-      -1,    82,   111,    83,    -1,   100,    -1,   100,    79,   111,
-      -1
+      86,     0,    -1,    87,    -1,    87,    89,    -1,    -1,    88,
+      87,    -1,    15,    98,    77,    -1,    90,    -1,    90,    89,
+      -1,    92,    77,    -1,     5,   101,   100,    91,    -1,     1,
+      77,    -1,    -1,     6,   101,   100,    91,    -1,     7,   100,
+      -1,     8,     4,    -1,    16,     4,    -1,     9,   110,     4,
+      -1,    10,   110,     4,    -1,    11,    -1,    12,    -1,    13,
+      -1,    14,    97,     4,    -1,    17,    98,    -1,    18,    98,
+      -1,    19,    98,    -1,    20,    -1,    21,    -1,    22,    94,
+      -1,    23,    95,    -1,    72,    93,     4,    -1,    75,    -1,
+      -1,    73,    -1,    74,    -1,    -1,    94,    65,     4,    -1,
+      94,    64,     4,    -1,    94,    66,    98,    -1,    94,    96,
+      -1,    94,    71,     4,    -1,    -1,    95,    96,    -1,    95,
+     107,     4,    -1,    95,   108,     4,    -1,    67,    -1,    68,
+      -1,    69,    -1,    -1,    97,    58,     3,    -1,    97,    59,
+      98,    -1,    97,    60,     4,    -1,    97,    61,     4,    -1,
+      97,    62,     4,    -1,    97,    63,    -1,    78,    99,    79,
+      -1,     4,    -1,     4,    -1,    99,    80,     4,    -1,    81,
+      89,    82,    -1,    81,    82,    -1,    24,   111,    -1,    25,
+     111,    -1,    26,    98,    -1,    27,    -1,    28,    -1,    29,
+     104,    98,    98,    -1,   102,   103,    98,    98,    -1,    34,
+     105,    98,    -1,    30,   101,    -1,    31,   109,     3,    -1,
+       1,    -1,    32,    -1,    33,    -1,    -1,   103,   106,    -1,
+     103,   107,    -1,   103,   108,     4,    -1,   103,    35,     4,
+      -1,    -1,   104,   107,    -1,   104,   108,     4,    -1,   104,
+      35,     4,    -1,    -1,   105,    55,    -1,   105,    56,    -1,
+     105,    57,    98,    -1,   105,   107,    -1,   105,   108,     4,
+      -1,   105,    35,     4,    -1,    50,    -1,    51,    -1,    52,
+      -1,    53,    -1,    54,    -1,    36,    -1,    37,    -1,    38,
+      -1,    39,    -1,    40,    -1,    41,    -1,    42,    -1,    43,
+      -1,    -1,    76,    -1,    83,   112,    84,    -1,   101,    -1,
+     101,    80,   112,    -1
 };
 
 /* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
 static const yytype_uint16 yyrline[] =
 {
        0,   214,   214,   215,   218,   219,   222,   230,   231,   234,
-     235,   236,   239,   240,   241,   244,   253,   261,   265,   266,
-     267,   268,   277,   286,   295,   304,   309,   315,   323,   333,
-     340,   347,   348,   349,   352,   353,   356,   359,   362,   365,
-     370,   371,   374,   389,   399,   400,   401,   404,   405,   408,
-     416,   422,   428,   434,   440,   441,   444,   445,   448,   449,
-     452,   453,   454,   455,   456,   457,   481,   503,   529,   530,
-     532,   535,   536,   543,   544,   549,   553,   561,   571,   572,
-     576,   584,   594,   595,   600,   605,   613,   617,   625,   636,
-     637,   638,   639,   644,   650,   651,   652,   653,   660,   665,
-     673,   674,   677,   678,   685,   688,   689
+     235,   236,   239,   240,   241,   244,   253,   262,   270,   274,
+     275,   276,   277,   286,   295,   304,   313,   318,   324,   332,
+     342,   349,   356,   357,   358,   361,   362,   365,   368,   371,
+     374,   379,   380,   383,   398,   408,   409,   410,   413,   414,
+     417,   425,   431,   437,   443,   449,   450,   453,   454,   457,
+     458,   461,   462,   463,   464,   465,   466,   490,   512,   538,
+     539,   541,   544,   545,   552,   553,   558,   562,   570,   580,
+     581,   585,   593,   603,   604,   609,   614,   622,   626,   634,
+     645,   646,   647,   648,   653,   659,   660,   661,   662,   669,
+     674,   682,   683,   686,   687,   694,   697,   698
 };
 #endif
 
@@ -787,13 +804,13 @@
 {
   "$end", "error", "$undefined", "NUMBER", "STRING", "IF", "ELSIF",
   "ELSE", "REJCT", "FILEINTO", "REDIRECT", "KEEP", "STOP", "DISCARD",
-  "VACATION", "REQUIRE", "SETFLAG", "ADDFLAG", "REMOVEFLAG", "MARK",
-  "UNMARK", "NOTIFY", "DENOTIFY", "ANYOF", "ALLOF", "EXISTS", "SFALSE",
-  "STRUE", "HEADER", "NOT", "SIZE", "ADDRESS", "ENVELOPE", "BODY",
-  "COMPARATOR", "IS", "CONTAINS", "MATCHES", "REGEX", "COUNT", "VALUE",
-  "OVER", "UNDER", "GT", "GE", "LT", "LE", "EQ", "NE", "ALL", "LOCALPART",
-  "DOMAIN", "USER", "DETAIL", "RAW", "TEXT", "CONTENT", "DAYS",
-  "ADDRESSES", "SUBJECT", "FROM", "HANDLE", "MIME", "METHOD", "ID",
+  "VACATION", "REQUIRE", "EREJCT", "SETFLAG", "ADDFLAG", "REMOVEFLAG",
+  "MARK", "UNMARK", "NOTIFY", "DENOTIFY", "ANYOF", "ALLOF", "EXISTS",
+  "SFALSE", "STRUE", "HEADER", "NOT", "SIZE", "ADDRESS", "ENVELOPE",
+  "BODY", "COMPARATOR", "IS", "CONTAINS", "MATCHES", "REGEX", "COUNT",
+  "VALUE", "OVER", "UNDER", "GT", "GE", "LT", "LE", "EQ", "NE", "ALL",
+  "LOCALPART", "DOMAIN", "USER", "DETAIL", "RAW", "TEXT", "CONTENT",
+  "DAYS", "ADDRESSES", "SUBJECT", "FROM", "HANDLE", "MIME", "METHOD", "ID",
   "OPTIONS", "LOW", "NORMAL", "HIGH", "ANY", "MESSAGE", "INCLUDE",
   "PERSONAL", "GLOBAL", "RETURN", "COPY", "';'", "'['", "']'", "','",
   "'{'", "'}'", "'('", "')'", "$accept", "start", "reqs", "require",
@@ -816,41 +833,41 @@
      295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
      305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
      315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
-     325,   326,   327,   328,   329,   330,    59,    91,    93,    44,
-     123,   125,    40,    41
+     325,   326,   327,   328,   329,   330,   331,    59,    91,    93,
+      44,   123,   125,    40,    41
 };
 # endif
 
 /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
 static const yytype_uint8 yyr1[] =
 {
-       0,    84,    85,    85,    86,    86,    87,    88,    88,    89,
-      89,    89,    90,    90,    90,    91,    91,    91,    91,    91,
-      91,    91,    91,    91,    91,    91,    91,    91,    91,    91,
-      91,    92,    92,    92,    93,    93,    93,    93,    93,    93,
-      94,    94,    94,    94,    95,    95,    95,    96,    96,    96,
-      96,    96,    96,    96,    97,    97,    98,    98,    99,    99,
-     100,   100,   100,   100,   100,   100,   100,   100,   100,   100,
-     100,   101,   101,   102,   102,   102,   102,   102,   103,   103,
-     103,   103,   104,   104,   104,   104,   104,   104,   104,   105,
-     105,   105,   105,   105,   106,   106,   106,   106,   107,   107,
-     108,   108,   109,   109,   110,   111,   111
+       0,    85,    86,    86,    87,    87,    88,    89,    89,    90,
+      90,    90,    91,    91,    91,    92,    92,    92,    92,    92,
+      92,    92,    92,    92,    92,    92,    92,    92,    92,    92,
+      92,    92,    93,    93,    93,    94,    94,    94,    94,    94,
+      94,    95,    95,    95,    95,    96,    96,    96,    97,    97,
+      97,    97,    97,    97,    97,    98,    98,    99,    99,   100,
+     100,   101,   101,   101,   101,   101,   101,   101,   101,   101,
+     101,   101,   102,   102,   103,   103,   103,   103,   103,   104,
+     104,   104,   104,   105,   105,   105,   105,   105,   105,   105,
+     106,   106,   106,   106,   106,   107,   107,   107,   107,   108,
+     108,   109,   109,   110,   110,   111,   112,   112
 };
 
 /* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
 static const yytype_uint8 yyr2[] =
 {
        0,     2,     1,     2,     0,     2,     3,     1,     2,     2,
-       4,     2,     0,     4,     2,     2,     3,     3,     1,     1,
-       1,     3,     2,     2,     2,     1,     1,     2,     2,     3,
-       1,     0,     1,     1,     0,     3,     3,     3,     2,     3,
-       0,     2,     3,     3,     1,     1,     1,     0,     3,     3,
-       3,     3,     3,     2,     3,     1,     1,     3,     3,     2,
-       2,     2,     2,     1,     1,     4,     4,     3,     2,     3,
-       1,     1,     1,     0,     2,     2,     3,     3,     0,     2,
-       3,     3,     0,     2,     2,     3,     2,     3,     3,     1,
+       4,     2,     0,     4,     2,     2,     2,     3,     3,     1,
+       1,     1,     3,     2,     2,     2,     1,     1,     2,     2,
+       3,     1,     0,     1,     1,     0,     3,     3,     3,     2,
+       3,     0,     2,     3,     3,     1,     1,     1,     0,     3,
+       3,     3,     3,     3,     2,     3,     1,     1,     3,     3,
+       2,     2,     2,     2,     1,     1,     4,     4,     3,     2,
+       3,     1,     1,     1,     0,     2,     2,     3,     3,     0,
+       2,     3,     3,     0,     2,     2,     3,     2,     3,     3,
        1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
-       1,     1,     0,     1,     3,     1,     3
+       1,     1,     1,     0,     1,     3,     1,     3
 };
 
 /* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
@@ -858,63 +875,63 @@
    means the default is an error.  */
 static const yytype_uint8 yydefact[] =
 {
-       4,     0,     0,     0,     4,    55,     0,     0,     1,     0,
-       0,     0,   102,   102,    18,    19,    20,    47,     0,     0,
-       0,    25,    26,    34,    40,    31,    30,     3,     0,     0,
-       5,    56,     0,     6,    11,    70,     0,     0,     0,    63,
-      64,    78,     0,     0,    71,    72,    82,     0,    73,    15,
-     103,     0,     0,     0,    22,    23,    24,    27,    28,    32,
-      33,     0,     8,     9,    54,     0,     0,    60,    61,    62,
-       0,    68,   100,   101,     0,     0,     0,    12,     0,    16,
-      17,    21,     0,     0,     0,     0,     0,    53,     0,     0,
-       0,    44,    45,    46,     0,    38,    94,    95,    96,    97,
-      98,    99,    41,     0,     0,    29,    57,   105,     0,     0,
-       0,    79,     0,    69,     0,    83,    84,     0,    67,    86,
-       0,    59,     0,     0,     0,    10,     0,    89,    90,    91,
-      92,    93,     0,    74,    75,     0,    48,    49,    50,    51,
-      52,    36,    35,    37,    39,    42,    43,     0,   104,    81,
-      65,    80,    88,    85,    87,    58,     0,    14,    77,    66,
-      76,   106,    12,    13
+       4,     0,     0,     0,     4,    56,     0,     0,     1,     0,
+       0,     0,   103,   103,    19,    20,    21,    48,     0,     0,
+       0,     0,    26,    27,    35,    41,    32,    31,     3,     0,
+       0,     5,    57,     0,     6,    11,    71,     0,     0,     0,
+      64,    65,    79,     0,     0,    72,    73,    83,     0,    74,
+      15,   104,     0,     0,     0,    16,    23,    24,    25,    28,
+      29,    33,    34,     0,     8,     9,    55,     0,     0,    61,
+      62,    63,     0,    69,   101,   102,     0,     0,     0,    12,
+       0,    17,    18,    22,     0,     0,     0,     0,     0,    54,
+       0,     0,     0,    45,    46,    47,     0,    39,    95,    96,
+      97,    98,    99,   100,    42,     0,     0,    30,    58,   106,
+       0,     0,     0,    80,     0,    70,     0,    84,    85,     0,
+      68,    87,     0,    60,     0,     0,     0,    10,     0,    90,
+      91,    92,    93,    94,     0,    75,    76,     0,    49,    50,
+      51,    52,    53,    37,    36,    38,    40,    43,    44,     0,
+     105,    82,    66,    81,    89,    86,    88,    59,     0,    14,
+      78,    67,    77,   107,    12,    13
 };
 
 /* YYDEFGOTO[NTERM-NUM].  */
 static const yytype_int16 yydefgoto[] =
 {
-      -1,     2,     3,     4,    27,    28,   125,    29,    61,    57,
-      58,    95,    53,     7,    32,    77,   107,    48,    78,    70,
-      75,   133,   103,   104,    74,    51,    67,   108
+      -1,     2,     3,     4,    28,    29,   127,    30,    63,    59,
+      60,    97,    54,     7,    33,    79,   109,    49,    80,    72,
+      77,   135,   105,   106,    76,    52,    69,   110
 };
 
 /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
    STATE-NUM.  */
-#define YYPACT_NINF -113
+#define YYPACT_NINF -115
 static const yytype_int16 yypact[] =
 {
-      -4,     0,    54,   112,    -4,  -113,    25,   -20,  -113,   -12,
-     215,    55,     6,     6,  -113,  -113,  -113,  -113,     0,     0,
-       0,  -113,  -113,  -113,  -113,   -64,  -113,  -113,     5,     2,
-    -113,  -113,   -47,  -113,  -113,  -113,    -2,    -2,     0,  -113,
-    -113,  -113,   215,    21,  -113,  -113,  -113,     4,  -113,  -113,
-    -113,    78,    79,    85,  -113,  -113,  -113,     3,   135,  -113,
-    -113,    81,  -113,  -113,  -113,    83,   215,  -113,  -113,  -113,
-     160,  -113,  -113,  -113,    87,   153,    29,    68,   101,  -113,
-    -113,  -113,    88,     0,    84,    89,    90,  -113,    91,    92,
-       0,  -113,  -113,  -113,    93,  -113,  -113,  -113,  -113,  -113,
-    -113,  -113,  -113,    94,    97,  -113,  -113,    23,    24,   100,
-       0,  -113,   102,  -113,   104,  -113,  -113,     0,  -113,  -113,
-     105,  -113,    30,   215,     4,  -113,   111,  -113,  -113,  -113,
-    -113,  -113,     0,  -113,  -113,   114,  -113,  -113,  -113,  -113,
-    -113,  -113,  -113,  -113,  -113,  -113,  -113,   215,  -113,  -113,
-    -113,  -113,  -113,  -113,  -113,  -113,     4,  -113,  -113,  -113,
-    -113,  -113,    68,  -113
+      -4,     0,    33,   112,    -4,  -115,    25,   -42,  -115,   -20,
+     194,    75,     6,     6,  -115,  -115,  -115,  -115,    77,     0,
+       0,     0,  -115,  -115,  -115,  -115,   -65,  -115,  -115,     5,
+       7,  -115,  -115,   -48,  -115,  -115,  -115,     2,     2,     0,
+    -115,  -115,  -115,   194,    22,  -115,  -115,  -115,     9,  -115,
+    -115,  -115,    79,    82,    85,  -115,  -115,  -115,  -115,     3,
+     129,  -115,  -115,    84,  -115,  -115,  -115,    87,   194,  -115,
+    -115,  -115,   123,  -115,  -115,  -115,    89,   153,    29,    69,
+     101,  -115,  -115,  -115,    91,     0,    92,    93,    94,  -115,
+      95,    98,     0,  -115,  -115,  -115,    99,  -115,  -115,  -115,
+    -115,  -115,  -115,  -115,  -115,   102,   103,  -115,  -115,    15,
+      24,   105,     0,  -115,   106,  -115,   110,  -115,  -115,     0,
+    -115,  -115,   115,  -115,    34,   194,     9,  -115,   145,  -115,
+    -115,  -115,  -115,  -115,     0,  -115,  -115,   146,  -115,  -115,
+    -115,  -115,  -115,  -115,  -115,  -115,  -115,  -115,  -115,   194,
+    -115,  -115,  -115,  -115,  -115,  -115,  -115,  -115,     9,  -115,
+    -115,  -115,  -115,  -115,    69,  -115
 };
 
 /* YYPGOTO[NTERM-NUM].  */
 static const yytype_int16 yypgoto[] =
 {
-    -113,  -113,   115,  -113,   -21,  -113,   -35,  -113,  -113,  -113,
-    -113,    98,  -113,   -18,  -113,  -112,    -7,  -113,  -113,  -113,
-    -113,  -113,   -42,   -17,  -113,   136,   118,     1
+    -115,  -115,   152,  -115,   -22,  -115,     8,  -115,  -115,  -115,
+    -115,   111,  -115,   -19,  -115,  -114,    -7,  -115,  -115,  -115,
+    -115,  -115,   -18,   -17,  -115,   160,   136,    26
 };
 
 /* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
@@ -924,83 +941,81 @@
 #define YYTABLE_NINF -8
 static const yytype_int16 yytable[] =
 {
-      54,    55,    56,    47,     5,    -7,     9,    62,    59,    60,
-      10,     1,   157,    11,    12,    13,    14,    15,    16,    17,
-      69,    18,    19,    20,    21,    22,    23,    24,   111,    31,
-       9,    64,    65,   119,    10,    71,   134,    11,    12,    13,
-      14,    15,    16,    17,   162,    18,    19,    20,    21,    22,
-      23,    24,   110,   112,     8,   122,    33,   118,   120,    49,
-     132,   135,    72,    73,    34,   137,    88,    89,    90,    91,
-      92,    93,   143,    94,   123,   124,    25,     6,    63,    26,
-      66,    50,    79,    80,    76,   105,    -7,   106,   138,    81,
-     113,   136,   150,   139,   140,   141,   142,   144,   145,   153,
-      25,   146,   147,    26,   149,     5,   151,   148,   152,   154,
-     121,   155,    -2,     9,   159,   158,   156,    10,   160,    30,
-      11,    12,    13,    14,    15,    16,    17,   163,    18,    19,
-      20,    21,    22,    23,    24,   126,    96,    97,    98,    99,
-     100,   101,    82,    83,    84,    85,    86,    87,   161,    52,
-     127,   128,   129,   130,   131,    68,   102,     5,     0,     0,
-       0,     0,     0,     0,     5,     0,     0,     0,     0,     0,
-      96,    97,    98,    99,   100,   101,     0,     0,     6,     0,
-       0,     0,     0,    25,     0,     0,    26,   114,    96,    97,
-      98,    99,   100,   101,   109,    96,    97,    98,    99,   100,
-     101,    91,    92,    93,     0,     0,     0,   115,   116,   117,
-       0,     0,     0,     0,     0,     0,    35,     0,     0,     0,
-       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
-       6,     0,     0,     0,     0,     0,     0,     6,    36,    37,
-      38,    39,    40,    41,    42,    43,    44,    45,    46
+      56,    57,    58,    48,     5,    -7,     9,    64,    61,    62,
+      10,     1,   159,    11,    12,    13,    14,    15,    16,    17,
+      71,    18,    19,    20,    21,    22,    23,    24,    25,    32,
+       9,    66,    67,     8,    10,    34,    73,    11,    12,    13,
+      14,    15,    16,    17,   164,    18,    19,    20,    21,    22,
+      23,    24,    25,   112,   113,   114,   124,    35,   120,   121,
+     122,   134,   136,   137,    74,    75,   139,    90,    91,    92,
+      93,    94,    95,   145,    96,   125,   126,    26,     6,    50,
+      27,    55,    51,    81,    65,    68,    82,    -7,   107,    83,
+      78,   108,   115,   152,   138,   149,   140,   141,   142,   143,
+     155,    26,   144,   146,    27,     5,   147,   148,   150,   151,
+     153,   123,    -2,     9,   154,   161,   157,    10,   158,   156,
+      11,    12,    13,    14,    15,    16,    17,     5,    18,    19,
+      20,    21,    22,    23,    24,    25,   128,    98,    99,   100,
+     101,   102,   103,    84,    85,    86,    87,    88,    89,   160,
+     162,   129,   130,   131,   132,   133,    31,     5,   111,    98,
+      99,   100,   101,   102,   103,    98,    99,   100,   101,   102,
+     103,   104,   165,    53,    70,   163,     0,     0,     0,     6,
+       0,     0,     0,     0,    26,     0,     0,    27,   116,    98,
+      99,   100,   101,   102,   103,    36,    93,    94,    95,     0,
+       0,     6,     0,     0,     0,     0,     0,     0,   117,   118,
+     119,     0,     0,     0,     0,     0,     0,     0,    37,    38,
+      39,    40,    41,    42,    43,    44,    45,    46,    47,     0,
+       0,     6
 };
 
 static const yytype_int16 yycheck[] =
 {
-      18,    19,    20,    10,     4,     0,     1,    28,    72,    73,
-       5,    15,   124,     8,     9,    10,    11,    12,    13,    14,
-      38,    16,    17,    18,    19,    20,    21,    22,    70,     4,
-       1,    78,    79,    75,     5,    42,    78,     8,     9,    10,
-      11,    12,    13,    14,   156,    16,    17,    18,    19,    20,
-      21,    22,    70,    70,     0,    76,    76,    75,    75,     4,
-      78,    78,    41,    42,    76,    83,    63,    64,    65,    66,
-      67,    68,    90,    70,     6,     7,    71,    77,    76,    74,
-      82,    75,     4,     4,    80,     4,    81,     4,     4,     4,
-       3,     3,   110,     4,     4,     4,     4,     4,     4,   117,
-      71,     4,    79,    74,     4,     4,     4,    83,     4,     4,
-      81,    81,     0,     1,   132,     4,   123,     5,     4,     4,
-       8,     9,    10,    11,    12,    13,    14,   162,    16,    17,
-      18,    19,    20,    21,    22,    34,    35,    36,    37,    38,
-      39,    40,    57,    58,    59,    60,    61,    62,   147,    13,
-      49,    50,    51,    52,    53,    37,    58,     4,    -1,    -1,
-      -1,    -1,    -1,    -1,     4,    -1,    -1,    -1,    -1,    -1,
-      35,    36,    37,    38,    39,    40,    -1,    -1,    77,    -1,
-      -1,    -1,    -1,    71,    -1,    -1,    74,    34,    35,    36,
-      37,    38,    39,    40,    34,    35,    36,    37,    38,    39,
-      40,    66,    67,    68,    -1,    -1,    -1,    54,    55,    56,
-      -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    -1,
-      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
-      77,    -1,    -1,    -1,    -1,    -1,    -1,    77,    23,    24,
-      25,    26,    27,    28,    29,    30,    31,    32,    33
+      19,    20,    21,    10,     4,     0,     1,    29,    73,    74,
+       5,    15,   126,     8,     9,    10,    11,    12,    13,    14,
+      39,    16,    17,    18,    19,    20,    21,    22,    23,     4,
+       1,    79,    80,     0,     5,    77,    43,     8,     9,    10,
+      11,    12,    13,    14,   158,    16,    17,    18,    19,    20,
+      21,    22,    23,    72,    72,    72,    78,    77,    77,    77,
+      77,    80,    80,    80,    42,    43,    85,    64,    65,    66,
+      67,    68,    69,    92,    71,     6,     7,    72,    78,     4,
+      75,     4,    76,     4,    77,    83,     4,    82,     4,     4,
+      81,     4,     3,   112,     3,    80,     4,     4,     4,     4,
+     119,    72,     4,     4,    75,     4,     4,     4,    84,     4,
+       4,    82,     0,     1,     4,   134,    82,     5,   125,     4,
+       8,     9,    10,    11,    12,    13,    14,     4,    16,    17,
+      18,    19,    20,    21,    22,    23,    35,    36,    37,    38,
+      39,    40,    41,    58,    59,    60,    61,    62,    63,     4,
+       4,    50,    51,    52,    53,    54,     4,     4,    35,    36,
+      37,    38,    39,    40,    41,    36,    37,    38,    39,    40,
+      41,    60,   164,    13,    38,   149,    -1,    -1,    -1,    78,
+      -1,    -1,    -1,    -1,    72,    -1,    -1,    75,    35,    36,
+      37,    38,    39,    40,    41,     1,    67,    68,    69,    -1,
+      -1,    78,    -1,    -1,    -1,    -1,    -1,    -1,    55,    56,
+      57,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    24,    25,
+      26,    27,    28,    29,    30,    31,    32,    33,    34,    -1,
+      -1,    78
 };
 
 /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
    symbol of state STATE-NUM.  */
 static const yytype_uint8 yystos[] =
 {
-       0,    15,    85,    86,    87,     4,    77,    97,     0,     1,
+       0,    15,    86,    87,    88,     4,    78,    98,     0,     1,
        5,     8,     9,    10,    11,    12,    13,    14,    16,    17,
-      18,    19,    20,    21,    22,    71,    74,    88,    89,    91,
-      86,     4,    98,    76,    76,     1,    23,    24,    25,    26,
-      27,    28,    29,    30,    31,    32,    33,   100,   101,     4,
-      75,   109,   109,    96,    97,    97,    97,    93,    94,    72,
-      73,    92,    88,    76,    78,    79,    82,   110,   110,    97,
-     103,   100,    41,    42,   108,   104,    80,    99,   102,     4,
-       4,     4,    57,    58,    59,    60,    61,    62,    63,    64,
-      65,    66,    67,    68,    70,    95,    35,    36,    37,    38,
-      39,    40,    95,   106,   107,     4,     4,   100,   111,    34,
-      97,   106,   107,     3,    34,    54,    55,    56,    97,   106,
-     107,    81,    88,     6,     7,    90,    34,    49,    50,    51,
-      52,    53,    97,   105,   106,   107,     3,    97,     4,     4,
-       4,     4,     4,    97,     4,     4,     4,    79,    83,     4,
-      97,     4,     4,    97,     4,    81,   100,    99,     4,    97,
-       4,   111,    99,    90
+      18,    19,    20,    21,    22,    23,    72,    75,    89,    90,
+      92,    87,     4,    99,    77,    77,     1,    24,    25,    26,
+      27,    28,    29,    30,    31,    32,    33,    34,   101,   102,
+       4,    76,   110,   110,    97,     4,    98,    98,    98,    94,
+      95,    73,    74,    93,    89,    77,    79,    80,    83,   111,
+     111,    98,   104,   101,    42,    43,   109,   105,    81,   100,
+     103,     4,     4,     4,    58,    59,    60,    61,    62,    63,
+      64,    65,    66,    67,    68,    69,    71,    96,    36,    37,
+      38,    39,    40,    41,    96,   107,   108,     4,     4,   101,
+     112,    35,    98,   107,   108,     3,    35,    55,    56,    57,
+      98,   107,   108,    82,    89,     6,     7,    91,    35,    50,
+      51,    52,    53,    54,    98,   106,   107,   108,     3,    98,
+       4,     4,     4,     4,     4,    98,     4,     4,     4,    80,
+      84,     4,    98,     4,     4,    98,     4,    82,   101,   100,
+       4,    98,     4,   112,   100,    91
 };
 
 #define yyerrok		(yyerrstatus = 0)
@@ -1185,17 +1200,20 @@
 #if (defined __STDC__ || defined __C99__FUNC__ \
      || defined __cplusplus || defined _MSC_VER)
 static void
-yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
+yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
 #else
 static void
-yy_stack_print (bottom, top)
-    yytype_int16 *bottom;
-    yytype_int16 *top;
+yy_stack_print (yybottom, yytop)
+    yytype_int16 *yybottom;
+    yytype_int16 *yytop;
 #endif
 {
   YYFPRINTF (stderr, "Stack now");
-  for (; bottom <= top; ++bottom)
-    YYFPRINTF (stderr, " %d", *bottom);
+  for (; yybottom <= yytop; yybottom++)
+    {
+      int yybot = *yybottom;
+      YYFPRINTF (stderr, " %d", yybot);
+    }
   YYFPRINTF (stderr, "\n");
 }
 
@@ -1229,11 +1247,11 @@
   /* The symbols being reduced.  */
   for (yyi = 0; yyi < yynrhs; yyi++)
     {
-      fprintf (stderr, "   $%d = ", yyi + 1);
+      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
       yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
 		       &(yyvsp[(yyi + 1) - (yynrhs)])
 		       		       );
-      fprintf (stderr, "\n");
+      YYFPRINTF (stderr, "\n");
     }
 }
 
@@ -1513,10 +1531,8 @@
 	break;
     }
 }
-
 
 /* Prevent warnings from -Wmissing-prototypes.  */
-
 #ifdef YYPARSE_PARAM
 #if defined __STDC__ || defined __cplusplus
 int yyparse (void *YYPARSE_PARAM);
@@ -1532,11 +1548,10 @@
 #endif /* ! YYPARSE_PARAM */
 
 
-
-/* The look-ahead symbol.  */
+/* The lookahead symbol.  */
 int yychar;
 
-/* The semantic value of the look-ahead symbol.  */
+/* The semantic value of the lookahead symbol.  */
 YYSTYPE yylval;
 
 /* Number of syntax errors so far.  */
@@ -1544,9 +1559,9 @@
 
 
 
-/*----------.
-| yyparse.  |
-`----------*/
+/*-------------------------.
+| yyparse or yypush_parse.  |
+`-------------------------*/
 
 #ifdef YYPARSE_PARAM
 #if (defined __STDC__ || defined __C99__FUNC__ \
@@ -1570,14 +1585,39 @@
 #endif
 #endif
 {
-  
-  int yystate;
+
+
+    int yystate;
+    /* Number of tokens to shift before error messages enabled.  */
+    int yyerrstatus;
+
+    /* The stacks and their tools:
+       `yyss': related to states.
+       `yyvs': related to semantic values.
+
+       Refer to the stacks thru separate pointers, to allow yyoverflow
+       to reallocate them elsewhere.  */
+
+    /* The state stack.  */
+    yytype_int16 yyssa[YYINITDEPTH];
+    yytype_int16 *yyss;
+    yytype_int16 *yyssp;
+
+    /* The semantic value stack.  */
+    YYSTYPE yyvsa[YYINITDEPTH];
+    YYSTYPE *yyvs;
+    YYSTYPE *yyvsp;
+
+    YYSIZE_T yystacksize;
+
   int yyn;
   int yyresult;
-  /* Number of tokens to shift before error messages enabled.  */
-  int yyerrstatus;
-  /* Look-ahead token as an internal (translated) token number.  */
-  int yytoken = 0;
+  /* Lookahead token as an internal (translated) token number.  */
+  int yytoken;
+  /* The variables used to return semantic value and location from the
+     action routines.  */
+  YYSTYPE yyval;
+
 #if YYERROR_VERBOSE
   /* Buffer for error messages, and its allocated size.  */
   char yymsgbuf[128];
@@ -1585,51 +1625,28 @@
   YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
 #endif
 
-  /* Three stacks and their tools:
-     `yyss': related to states,
-     `yyvs': related to semantic values,
-     `yyls': related to locations.
-
-     Refer to the stacks thru separate pointers, to allow yyoverflow
-     to reallocate them elsewhere.  */
-
-  /* The state stack.  */
-  yytype_int16 yyssa[YYINITDEPTH];
-  yytype_int16 *yyss = yyssa;
-  yytype_int16 *yyssp;
-
-  /* The semantic value stack.  */
-  YYSTYPE yyvsa[YYINITDEPTH];
-  YYSTYPE *yyvs = yyvsa;
-  YYSTYPE *yyvsp;
-
-
-
 #define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))
 
-  YYSIZE_T yystacksize = YYINITDEPTH;
-
-  /* The variables used to return semantic value and location from the
-     action routines.  */
-  YYSTYPE yyval;
-
-
   /* The number of symbols on the RHS of the reduced rule.
      Keep to zero when no symbol should be popped.  */
   int yylen = 0;
 
+  yytoken = 0;
+  yyss = yyssa;
+  yyvs = yyvsa;
+  yystacksize = YYINITDEPTH;
+
   YYDPRINTF ((stderr, "Starting parse\n"));
 
   yystate = 0;
   yyerrstatus = 0;
   yynerrs = 0;
-  yychar = YYEMPTY;		/* Cause a token to be read.  */
+  yychar = YYEMPTY; /* Cause a token to be read.  */
 
   /* Initialize stack pointers.
      Waste one element of value and location stack
      so that they stay on the same level as the state stack.
      The wasted elements are never initialized.  */
-
   yyssp = yyss;
   yyvsp = yyvs;
 
@@ -1659,7 +1676,6 @@
 	YYSTYPE *yyvs1 = yyvs;
 	yytype_int16 *yyss1 = yyss;
 
-
 	/* Each stack pointer address is followed by the size of the
 	   data in use in that stack, in bytes.  This used to be a
 	   conditional around just the two extra args, but that might
@@ -1667,7 +1683,6 @@
 	yyoverflow (YY_("memory exhausted"),
 		    &yyss1, yysize * sizeof (*yyssp),
 		    &yyvs1, yysize * sizeof (*yyvsp),
-
 		    &yystacksize);
 
 	yyss = yyss1;
@@ -1690,9 +1705,8 @@
 	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
 	if (! yyptr)
 	  goto yyexhaustedlab;
-	YYSTACK_RELOCATE (yyss);
-	YYSTACK_RELOCATE (yyvs);
-
+	YYSTACK_RELOCATE (yyss_alloc, yyss);
+	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
 #  undef YYSTACK_RELOCATE
 	if (yyss1 != yyssa)
 	  YYSTACK_FREE (yyss1);
@@ -1703,7 +1717,6 @@
       yyssp = yyss + yysize - 1;
       yyvsp = yyvs + yysize - 1;
 
-
       YYDPRINTF ((stderr, "Stack size increased to %lu\n",
 		  (unsigned long int) yystacksize));
 
@@ -1713,6 +1726,9 @@
 
   YYDPRINTF ((stderr, "Entering state %d\n", yystate));
 
+  if (yystate == YYFINAL)
+    YYACCEPT;
+
   goto yybackup;
 
 /*-----------.
@@ -1721,16 +1737,16 @@
 yybackup:
 
   /* Do appropriate processing given the current state.  Read a
-     look-ahead token if we need one and don't already have one.  */
+     lookahead token if we need one and don't already have one.  */
 
-  /* First try to decide what to do without reference to look-ahead token.  */
+  /* First try to decide what to do without reference to lookahead token.  */
   yyn = yypact[yystate];
   if (yyn == YYPACT_NINF)
     goto yydefault;
 
-  /* Not known => get a look-ahead token if don't already have one.  */
+  /* Not known => get a lookahead token if don't already have one.  */
 
-  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
+  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
   if (yychar == YYEMPTY)
     {
       YYDPRINTF ((stderr, "Reading a token: "));
@@ -1762,20 +1778,16 @@
       goto yyreduce;
     }
 
-  if (yyn == YYFINAL)
-    YYACCEPT;
-
   /* Count tokens shifted since error; after three, turn off error
      status.  */
   if (yyerrstatus)
     yyerrstatus--;
 
-  /* Shift the look-ahead token.  */
+  /* Shift the lookahead token.  */
   YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
 
-  /* Discard the shifted token unless it is eof.  */
-  if (yychar != YYEOF)
-    yychar = YYEMPTY;
+  /* Discard the shifted token.  */
+  yychar = YYEMPTY;
 
   yystate = yyn;
   *++yyvsp = yylval;
@@ -1815,17 +1827,23 @@
   switch (yyn)
     {
         case 2:
-#line 214 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 214 "./sieve.y"
     { ret = NULL; }
     break;
 
   case 3:
-#line 215 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 215 "./sieve.y"
     { ret = (yyvsp[(2) - (2)].cl); }
     break;
 
   case 6:
-#line 222 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 222 "./sieve.y"
     { char *err = check_reqs((yyvsp[(2) - (3)].sl));
                                   if (err) {
 				    yyerror(err);
@@ -1835,47 +1853,65 @@
     break;
 
   case 7:
-#line 230 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 230 "./sieve.y"
     { (yyval.cl) = (yyvsp[(1) - (1)].cl); }
     break;
 
   case 8:
-#line 231 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 231 "./sieve.y"
     { (yyvsp[(1) - (2)].cl)->next = (yyvsp[(2) - (2)].cl); (yyval.cl) = (yyvsp[(1) - (2)].cl); }
     break;
 
   case 9:
-#line 234 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 234 "./sieve.y"
     { (yyval.cl) = (yyvsp[(1) - (2)].cl); }
     break;
 
   case 10:
-#line 235 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 235 "./sieve.y"
     { (yyval.cl) = new_if((yyvsp[(2) - (4)].test), (yyvsp[(3) - (4)].cl), (yyvsp[(4) - (4)].cl)); }
     break;
 
   case 11:
-#line 236 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 236 "./sieve.y"
     { (yyval.cl) = new_command(STOP); }
     break;
 
   case 12:
-#line 239 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 239 "./sieve.y"
     { (yyval.cl) = NULL; }
     break;
 
   case 13:
-#line 240 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 240 "./sieve.y"
     { (yyval.cl) = new_if((yyvsp[(2) - (4)].test), (yyvsp[(3) - (4)].cl), (yyvsp[(4) - (4)].cl)); }
     break;
 
   case 14:
-#line 241 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 241 "./sieve.y"
     { (yyval.cl) = (yyvsp[(2) - (2)].cl); }
     break;
 
   case 15:
-#line 244 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 244 "./sieve.y"
     { if (!parse_script->support.reject) {
 				     yyerror("reject MUST be enabled with \"require\"");
 				     YYERROR;
@@ -1888,7 +1924,24 @@
     break;
 
   case 16:
-#line 253 "sieve.y"
+
+/* Line 1455 of yacc.c  */
+#line 253 "./sieve.y"
+    { if (!parse_script->support.ereject) {
+				     yyerror("ereject MUST be enabled with \"require\"");
+				     YYERROR;
+				   }
+				   if (!verify_utf8((yyvsp[(2) - (2)].sval))) {
+				     YYERROR; /* vu should call yyerror() */
+				   }
+				   (yyval.cl) = new_command(EREJCT);
+				   (yyval.cl)->u.str = (yyvsp[(2) - (2)].sval); }
+    break;
+
+  case 17:
+
+/* Line 1455 of yacc.c  */
+#line 262 "./sieve.y"
     { if (!parse_script->support.fileinto) {
 				     yyerror("fileinto MUST be enabled with \"require\"");
 	                             YYERROR;
@@ -1899,31 +1952,41 @@
 	                           (yyval.cl) = build_fileinto(FILEINTO, (yyvsp[(2) - (3)].nval), (yyvsp[(3) - (3)].sval)); }
     break;
 
-  case 17:
-#line 261 "sieve.y"
+  case 18:
+
+/* Line 1455 of yacc.c  */
+#line 270 "./sieve.y"
     { if (!verify_address((yyvsp[(3) - (3)].sval))) {
 				     YYERROR; /* va should call yyerror() */
 				   }
 	                           (yyval.cl) = build_redirect(REDIRECT, (yyvsp[(2) - (3)].nval), (yyvsp[(3) - (3)].sval)); }
     break;
 
-  case 18:
-#line 265 "sieve.y"
+  case 19:
+
+/* Line 1455 of yacc.c  */
+#line 274 "./sieve.y"
     { (yyval.cl) = new_command(KEEP); }
     break;
 
-  case 19:
-#line 266 "sieve.y"
+  case 20:
+
+/* Line 1455 of yacc.c  */
+#line 275 "./sieve.y"
     { (yyval.cl) = new_command(STOP); }
     break;
 
-  case 20:
-#line 267 "sieve.y"
+  case 21:
+
+/* Line 1455 of yacc.c  */
+#line 276 "./sieve.y"
     { (yyval.cl) = new_command(DISCARD); }
     break;
 
-  case 21:
-#line 268 "sieve.y"
+  case 22:
+
+/* Line 1455 of yacc.c  */
+#line 277 "./sieve.y"
     { if (!parse_script->support.vacation) {
 				     yyerror("vacation MUST be enabled with \"require\"");
 				     YYERROR;
@@ -1935,8 +1998,10 @@
 					    canon_vtags((yyvsp[(2) - (3)].vtag)), (yyvsp[(3) - (3)].sval)); }
     break;
 
-  case 22:
-#line 277 "sieve.y"
+  case 23:
+
+/* Line 1455 of yacc.c  */
+#line 286 "./sieve.y"
     { if (!parse_script->support.imapflags) {
                                     yyerror("imapflags MUST be enabled with \"require\"");
                                     YYERROR;
@@ -1948,8 +2013,10 @@
                                   (yyval.cl)->u.sl = (yyvsp[(2) - (2)].sl); }
     break;
 
-  case 23:
-#line 286 "sieve.y"
+  case 24:
+
+/* Line 1455 of yacc.c  */
+#line 295 "./sieve.y"
     { if (!parse_script->support.imapflags) {
                                     yyerror("imapflags MUST be enabled with \"require\"");
                                     YYERROR;
@@ -1961,8 +2028,10 @@
                                   (yyval.cl)->u.sl = (yyvsp[(2) - (2)].sl); }
     break;
 
-  case 24:
-#line 295 "sieve.y"
+  case 25:
+
+/* Line 1455 of yacc.c  */
+#line 304 "./sieve.y"
     { if (!parse_script->support.imapflags) {
                                     yyerror("imapflags MUST be enabled with \"require\"");
                                     YYERROR;
@@ -1974,8 +2043,10 @@
                                   (yyval.cl)->u.sl = (yyvsp[(2) - (2)].sl); }
     break;
 
-  case 25:
-#line 304 "sieve.y"
+  case 26:
+
+/* Line 1455 of yacc.c  */
+#line 313 "./sieve.y"
     { if (!parse_script->support.imapflags) {
                                     yyerror("imapflags MUST be enabled with \"require\"");
                                     YYERROR;
@@ -1983,8 +2054,10 @@
                                   (yyval.cl) = new_command(MARK); }
     break;
 
-  case 26:
-#line 309 "sieve.y"
+  case 27:
+
+/* Line 1455 of yacc.c  */
+#line 318 "./sieve.y"
     { if (!parse_script->support.imapflags) {
                                     yyerror("imapflags MUST be enabled with \"require\"");
                                     YYERROR;
@@ -1992,8 +2065,10 @@
                                   (yyval.cl) = new_command(UNMARK); }
     break;
 
-  case 27:
-#line 315 "sieve.y"
+  case 28:
+
+/* Line 1455 of yacc.c  */
+#line 324 "./sieve.y"
     { if (!parse_script->support.notify) {
 				       yyerror("notify MUST be enabled with \"require\"");
 				       (yyval.cl) = new_command(NOTIFY); 
@@ -2004,8 +2079,10 @@
 				    } }
     break;
 
-  case 28:
-#line 323 "sieve.y"
+  case 29:
+
+/* Line 1455 of yacc.c  */
+#line 332 "./sieve.y"
     { if (!parse_script->support.notify) {
                                        yyerror("notify MUST be enabled with \"require\"");
 				       (yyval.cl) = new_command(DENOTIFY);
@@ -2017,8 +2094,10 @@
 			YYERROR; } } }
     break;
 
-  case 29:
-#line 333 "sieve.y"
+  case 30:
+
+/* Line 1455 of yacc.c  */
+#line 342 "./sieve.y"
     { if (!parse_script->support.include) {
 				     yyerror("include MUST be enabled with \"require\"");
 	                             YYERROR;
@@ -2028,8 +2107,10 @@
 				   (yyval.cl)->u.inc.script = (yyvsp[(3) - (3)].sval); }
     break;
 
-  case 30:
-#line 340 "sieve.y"
+  case 31:
+
+/* Line 1455 of yacc.c  */
+#line 349 "./sieve.y"
     { if (!parse_script->support.include) {
                                     yyerror("include MUST be enabled with \"require\"");
                                     YYERROR;
@@ -2037,75 +2118,99 @@
                                    (yyval.cl) = new_command(RETURN); }
     break;
 
-  case 31:
-#line 347 "sieve.y"
+  case 32:
+
+/* Line 1455 of yacc.c  */
+#line 356 "./sieve.y"
     { (yyval.nval) = PERSONAL; }
     break;
 
-  case 32:
-#line 348 "sieve.y"
+  case 33:
+
+/* Line 1455 of yacc.c  */
+#line 357 "./sieve.y"
     { (yyval.nval) = PERSONAL; }
     break;
 
-  case 33:
-#line 349 "sieve.y"
+  case 34:
+
+/* Line 1455 of yacc.c  */
+#line 358 "./sieve.y"
     { (yyval.nval) = GLOBAL; }
     break;
 
-  case 34:
-#line 352 "sieve.y"
+  case 35:
+
+/* Line 1455 of yacc.c  */
+#line 361 "./sieve.y"
     { (yyval.ntag) = new_ntags(); }
     break;
 
-  case 35:
-#line 353 "sieve.y"
+  case 36:
+
+/* Line 1455 of yacc.c  */
+#line 362 "./sieve.y"
     { if ((yyval.ntag)->id != NULL) { 
 					yyerror("duplicate :method"); YYERROR; }
 				   else { (yyval.ntag)->id = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 36:
-#line 356 "sieve.y"
+  case 37:
+
+/* Line 1455 of yacc.c  */
+#line 365 "./sieve.y"
     { if ((yyval.ntag)->method != NULL) { 
 					yyerror("duplicate :method"); YYERROR; }
 				   else { (yyval.ntag)->method = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 37:
-#line 359 "sieve.y"
+  case 38:
+
+/* Line 1455 of yacc.c  */
+#line 368 "./sieve.y"
     { if ((yyval.ntag)->options != NULL) { 
 					yyerror("duplicate :options"); YYERROR; }
 				     else { (yyval.ntag)->options = (yyvsp[(3) - (3)].sl); } }
     break;
 
-  case 38:
-#line 362 "sieve.y"
+  case 39:
+
+/* Line 1455 of yacc.c  */
+#line 371 "./sieve.y"
     { if ((yyval.ntag)->priority != -1) { 
                                  yyerror("duplicate :priority"); YYERROR; }
                                    else { (yyval.ntag)->priority = (yyvsp[(2) - (2)].nval); } }
     break;
 
-  case 39:
-#line 365 "sieve.y"
+  case 40:
+
+/* Line 1455 of yacc.c  */
+#line 374 "./sieve.y"
     { if ((yyval.ntag)->message != NULL) { 
 					yyerror("duplicate :message"); YYERROR; }
 				   else { (yyval.ntag)->message = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 40:
-#line 370 "sieve.y"
+  case 41:
+
+/* Line 1455 of yacc.c  */
+#line 379 "./sieve.y"
     { (yyval.dtag) = new_dtags(); }
     break;
 
-  case 41:
-#line 371 "sieve.y"
+  case 42:
+
+/* Line 1455 of yacc.c  */
+#line 380 "./sieve.y"
     { if ((yyval.dtag)->priority != -1) { 
 				yyerror("duplicate priority level"); YYERROR; }
 				   else { (yyval.dtag)->priority = (yyvsp[(2) - (2)].nval); } }
     break;
 
-  case 42:
-#line 374 "sieve.y"
+  case 43:
+
+/* Line 1455 of yacc.c  */
+#line 383 "./sieve.y"
     { if ((yyval.dtag)->comptag != -1)
 	                             { 
 					 yyerror("duplicate comparator type tag"); YYERROR;
@@ -2123,8 +2228,10 @@
 	                          }
     break;
 
-  case 43:
-#line 389 "sieve.y"
+  case 44:
+
+/* Line 1455 of yacc.c  */
+#line 398 "./sieve.y"
     { (yyval.dtag) = (yyvsp[(1) - (3)].dtag);
 				   if ((yyval.dtag)->comptag != -1) { 
 			yyerror("duplicate comparator type tag"); YYERROR; }
@@ -2135,35 +2242,47 @@
 				   } }
     break;
 
-  case 44:
-#line 399 "sieve.y"
+  case 45:
+
+/* Line 1455 of yacc.c  */
+#line 408 "./sieve.y"
     { (yyval.nval) = LOW; }
     break;
 
-  case 45:
-#line 400 "sieve.y"
+  case 46:
+
+/* Line 1455 of yacc.c  */
+#line 409 "./sieve.y"
     { (yyval.nval) = NORMAL; }
     break;
 
-  case 46:
-#line 401 "sieve.y"
+  case 47:
+
+/* Line 1455 of yacc.c  */
+#line 410 "./sieve.y"
     { (yyval.nval) = HIGH; }
     break;
 
-  case 47:
-#line 404 "sieve.y"
+  case 48:
+
+/* Line 1455 of yacc.c  */
+#line 413 "./sieve.y"
     { (yyval.vtag) = new_vtags(); }
     break;
 
-  case 48:
-#line 405 "sieve.y"
+  case 49:
+
+/* Line 1455 of yacc.c  */
+#line 414 "./sieve.y"
     { if ((yyval.vtag)->days != -1) { 
 					yyerror("duplicate :days"); YYERROR; }
 				   else { (yyval.vtag)->days = (yyvsp[(3) - (3)].nval); } }
     break;
 
-  case 49:
-#line 408 "sieve.y"
+  case 50:
+
+/* Line 1455 of yacc.c  */
+#line 417 "./sieve.y"
     { if ((yyval.vtag)->addresses != NULL) { 
 					yyerror("duplicate :addresses"); 
 					YYERROR;
@@ -2174,8 +2293,10 @@
 					 (yyval.vtag)->addresses = (yyvsp[(3) - (3)].sl); } }
     break;
 
-  case 50:
-#line 416 "sieve.y"
+  case 51:
+
+/* Line 1455 of yacc.c  */
+#line 425 "./sieve.y"
     { if ((yyval.vtag)->subject != NULL) { 
 					yyerror("duplicate :subject"); 
 					YYERROR;
@@ -2184,8 +2305,10 @@
 				   } else { (yyval.vtag)->subject = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 51:
-#line 422 "sieve.y"
+  case 52:
+
+/* Line 1455 of yacc.c  */
+#line 431 "./sieve.y"
     { if ((yyval.vtag)->from != NULL) { 
 					yyerror("duplicate :from"); 
 					YYERROR;
@@ -2194,8 +2317,10 @@
 				   } else { (yyval.vtag)->from = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 52:
-#line 428 "sieve.y"
+  case 53:
+
+/* Line 1455 of yacc.c  */
+#line 437 "./sieve.y"
     { if ((yyval.vtag)->handle != NULL) { 
 					yyerror("duplicate :handle"); 
 					YYERROR;
@@ -2204,71 +2329,97 @@
 				   } else { (yyval.vtag)->handle = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 53:
-#line 434 "sieve.y"
+  case 54:
+
+/* Line 1455 of yacc.c  */
+#line 443 "./sieve.y"
     { if ((yyval.vtag)->mime != -1) { 
 					yyerror("duplicate :mime"); 
 					YYERROR; }
 				   else { (yyval.vtag)->mime = MIME; } }
     break;
 
-  case 54:
-#line 440 "sieve.y"
+  case 55:
+
+/* Line 1455 of yacc.c  */
+#line 449 "./sieve.y"
     { (yyval.sl) = sl_reverse((yyvsp[(2) - (3)].sl)); }
     break;
 
-  case 55:
-#line 441 "sieve.y"
+  case 56:
+
+/* Line 1455 of yacc.c  */
+#line 450 "./sieve.y"
     { (yyval.sl) = new_sl((yyvsp[(1) - (1)].sval), NULL); }
     break;
 
-  case 56:
-#line 444 "sieve.y"
+  case 57:
+
+/* Line 1455 of yacc.c  */
+#line 453 "./sieve.y"
     { (yyval.sl) = new_sl((yyvsp[(1) - (1)].sval), NULL); }
     break;
 
-  case 57:
-#line 445 "sieve.y"
+  case 58:
+
+/* Line 1455 of yacc.c  */
+#line 454 "./sieve.y"
     { (yyval.sl) = new_sl((yyvsp[(3) - (3)].sval), (yyvsp[(1) - (3)].sl)); }
     break;
 
-  case 58:
-#line 448 "sieve.y"
+  case 59:
+
+/* Line 1455 of yacc.c  */
+#line 457 "./sieve.y"
     { (yyval.cl) = (yyvsp[(2) - (3)].cl); }
     break;
 
-  case 59:
-#line 449 "sieve.y"
+  case 60:
+
+/* Line 1455 of yacc.c  */
+#line 458 "./sieve.y"
     { (yyval.cl) = NULL; }
     break;
 
-  case 60:
-#line 452 "sieve.y"
+  case 61:
+
+/* Line 1455 of yacc.c  */
+#line 461 "./sieve.y"
     { (yyval.test) = new_test(ANYOF); (yyval.test)->u.tl = (yyvsp[(2) - (2)].testl); }
     break;
 
-  case 61:
-#line 453 "sieve.y"
+  case 62:
+
+/* Line 1455 of yacc.c  */
+#line 462 "./sieve.y"
     { (yyval.test) = new_test(ALLOF); (yyval.test)->u.tl = (yyvsp[(2) - (2)].testl); }
     break;
 
-  case 62:
-#line 454 "sieve.y"
+  case 63:
+
+/* Line 1455 of yacc.c  */
+#line 463 "./sieve.y"
     { (yyval.test) = new_test(EXISTS); (yyval.test)->u.sl = (yyvsp[(2) - (2)].sl); }
     break;
 
-  case 63:
-#line 455 "sieve.y"
+  case 64:
+
+/* Line 1455 of yacc.c  */
+#line 464 "./sieve.y"
     { (yyval.test) = new_test(SFALSE); }
     break;
 
-  case 64:
-#line 456 "sieve.y"
+  case 65:
+
+/* Line 1455 of yacc.c  */
+#line 465 "./sieve.y"
     { (yyval.test) = new_test(STRUE); }
     break;
 
-  case 65:
-#line 458 "sieve.y"
+  case 66:
+
+/* Line 1455 of yacc.c  */
+#line 467 "./sieve.y"
     {
 				     if (!verify_stringlist((yyvsp[(3) - (4)].sl), verify_header)) {
 					 YYERROR; /* vh should call yyerror() */
@@ -2292,8 +2443,10 @@
 				 }
     break;
 
-  case 66:
-#line 482 "sieve.y"
+  case 67:
+
+/* Line 1455 of yacc.c  */
+#line 491 "./sieve.y"
     { 
 				     if (((yyvsp[(1) - (4)].nval) == ADDRESS) &&
 					 !verify_stringlist((yyvsp[(3) - (4)].sl), verify_addrheader))
@@ -2316,8 +2469,10 @@
 				 }
     break;
 
-  case 67:
-#line 504 "sieve.y"
+  case 68:
+
+/* Line 1455 of yacc.c  */
+#line 513 "./sieve.y"
     {
 				     if (!parse_script->support.body) {
                                        yyerror("body MUST be enabled with \"require\"");
@@ -2343,42 +2498,56 @@
 				 }
     break;
 
-  case 68:
-#line 529 "sieve.y"
+  case 69:
+
+/* Line 1455 of yacc.c  */
+#line 538 "./sieve.y"
     { (yyval.test) = new_test(NOT); (yyval.test)->u.t = (yyvsp[(2) - (2)].test); }
     break;
 
-  case 69:
-#line 530 "sieve.y"
+  case 70:
+
+/* Line 1455 of yacc.c  */
+#line 539 "./sieve.y"
     { (yyval.test) = new_test(SIZE); (yyval.test)->u.sz.t = (yyvsp[(2) - (3)].nval);
 		                   (yyval.test)->u.sz.n = (yyvsp[(3) - (3)].nval); }
     break;
 
-  case 70:
-#line 532 "sieve.y"
+  case 71:
+
+/* Line 1455 of yacc.c  */
+#line 541 "./sieve.y"
     { (yyval.test) = NULL; }
     break;
 
-  case 71:
-#line 535 "sieve.y"
+  case 72:
+
+/* Line 1455 of yacc.c  */
+#line 544 "./sieve.y"
     { (yyval.nval) = ADDRESS; }
     break;
 
-  case 72:
-#line 536 "sieve.y"
+  case 73:
+
+/* Line 1455 of yacc.c  */
+#line 545 "./sieve.y"
     {if (!parse_script->support.envelope)
 	                              {yyerror("envelope MUST be enabled with \"require\""); YYERROR;}
 	                          else{(yyval.nval) = ENVELOPE; }
 	                         }
     break;
 
-  case 73:
-#line 543 "sieve.y"
+  case 74:
+
+/* Line 1455 of yacc.c  */
+#line 552 "./sieve.y"
     { (yyval.aetag) = new_aetags(); }
     break;
 
-  case 74:
-#line 544 "sieve.y"
+  case 75:
+
+/* Line 1455 of yacc.c  */
+#line 553 "./sieve.y"
     { (yyval.aetag) = (yyvsp[(1) - (2)].aetag);
 				   if ((yyval.aetag)->addrtag != -1) { 
 			yyerror("duplicate or conflicting address part tag");
@@ -2386,16 +2555,20 @@
 				   else { (yyval.aetag)->addrtag = (yyvsp[(2) - (2)].nval); } }
     break;
 
-  case 75:
-#line 549 "sieve.y"
+  case 76:
+
+/* Line 1455 of yacc.c  */
+#line 558 "./sieve.y"
     { (yyval.aetag) = (yyvsp[(1) - (2)].aetag);
 				   if ((yyval.aetag)->comptag != -1) { 
 			yyerror("duplicate comparator type tag"); YYERROR; }
 				   else { (yyval.aetag)->comptag = (yyvsp[(2) - (2)].nval); } }
     break;
 
-  case 76:
-#line 553 "sieve.y"
+  case 77:
+
+/* Line 1455 of yacc.c  */
+#line 562 "./sieve.y"
     { (yyval.aetag) = (yyvsp[(1) - (3)].aetag);
 				   if ((yyval.aetag)->comptag != -1) { 
 			yyerror("duplicate comparator type tag"); YYERROR; }
@@ -2406,8 +2579,10 @@
 				   } }
     break;
 
-  case 77:
-#line 561 "sieve.y"
+  case 78:
+
+/* Line 1455 of yacc.c  */
+#line 570 "./sieve.y"
     { (yyval.aetag) = (yyvsp[(1) - (3)].aetag);
 	if ((yyval.aetag)->comparator != NULL) { 
 			yyerror("duplicate comparator tag"); YYERROR; }
@@ -2418,21 +2593,27 @@
 				   else { (yyval.aetag)->comparator = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 78:
-#line 571 "sieve.y"
+  case 79:
+
+/* Line 1455 of yacc.c  */
+#line 580 "./sieve.y"
     { (yyval.htag) = new_htags(); }
     break;
 
-  case 79:
-#line 572 "sieve.y"
+  case 80:
+
+/* Line 1455 of yacc.c  */
+#line 581 "./sieve.y"
     { (yyval.htag) = (yyvsp[(1) - (2)].htag);
 				   if ((yyval.htag)->comptag != -1) { 
 			yyerror("duplicate comparator type tag"); YYERROR; }
 				   else { (yyval.htag)->comptag = (yyvsp[(2) - (2)].nval); } }
     break;
 
-  case 80:
-#line 576 "sieve.y"
+  case 81:
+
+/* Line 1455 of yacc.c  */
+#line 585 "./sieve.y"
     { (yyval.htag) = (yyvsp[(1) - (3)].htag);
 				   if ((yyval.htag)->comptag != -1) { 
 			yyerror("duplicate comparator type tag"); YYERROR; }
@@ -2443,8 +2624,10 @@
 				   } }
     break;
 
-  case 81:
-#line 584 "sieve.y"
+  case 82:
+
+/* Line 1455 of yacc.c  */
+#line 593 "./sieve.y"
     { (yyval.htag) = (yyvsp[(1) - (3)].htag);
 				   if ((yyval.htag)->comparator != NULL) { 
 			 yyerror("duplicate comparator tag"); YYERROR; }
@@ -2455,13 +2638,17 @@
 				     (yyval.htag)->comparator = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 82:
-#line 594 "sieve.y"
+  case 83:
+
+/* Line 1455 of yacc.c  */
+#line 603 "./sieve.y"
     { (yyval.btag) = new_btags(); }
     break;
 
-  case 83:
-#line 595 "sieve.y"
+  case 84:
+
+/* Line 1455 of yacc.c  */
+#line 604 "./sieve.y"
     { (yyval.btag) = (yyvsp[(1) - (2)].btag);
 				   if ((yyval.btag)->transform != -1) {
 			yyerror("duplicate or conflicting transform tag");
@@ -2469,8 +2656,10 @@
 				   else { (yyval.btag)->transform = RAW; } }
     break;
 
-  case 84:
-#line 600 "sieve.y"
+  case 85:
+
+/* Line 1455 of yacc.c  */
+#line 609 "./sieve.y"
     { (yyval.btag) = (yyvsp[(1) - (2)].btag);
 				   if ((yyval.btag)->transform != -1) {
 			yyerror("duplicate or conflicting transform tag");
@@ -2478,8 +2667,10 @@
 				   else { (yyval.btag)->transform = TEXT; } }
     break;
 
-  case 85:
-#line 605 "sieve.y"
+  case 86:
+
+/* Line 1455 of yacc.c  */
+#line 614 "./sieve.y"
     { (yyval.btag) = (yyvsp[(1) - (3)].btag);
 				   if ((yyval.btag)->transform != -1) {
 			yyerror("duplicate or conflicting transform tag");
@@ -2490,16 +2681,20 @@
 				   } }
     break;
 
-  case 86:
-#line 613 "sieve.y"
+  case 87:
+
+/* Line 1455 of yacc.c  */
+#line 622 "./sieve.y"
     { (yyval.btag) = (yyvsp[(1) - (2)].btag);
 				   if ((yyval.btag)->comptag != -1) { 
 			yyerror("duplicate comparator type tag"); YYERROR; }
 				   else { (yyval.btag)->comptag = (yyvsp[(2) - (2)].nval); } }
     break;
 
-  case 87:
-#line 617 "sieve.y"
+  case 88:
+
+/* Line 1455 of yacc.c  */
+#line 626 "./sieve.y"
     { (yyval.btag) = (yyvsp[(1) - (3)].btag);
 				   if ((yyval.btag)->comptag != -1) { 
 			yyerror("duplicate comparator type tag"); YYERROR; }
@@ -2510,8 +2705,10 @@
 				   } }
     break;
 
-  case 88:
-#line 625 "sieve.y"
+  case 89:
+
+/* Line 1455 of yacc.c  */
+#line 634 "./sieve.y"
     { (yyval.btag) = (yyvsp[(1) - (3)].btag);
 				   if ((yyval.btag)->comparator != NULL) { 
 			 yyerror("duplicate comparator tag"); YYERROR; }
@@ -2522,23 +2719,31 @@
 				     (yyval.btag)->comparator = (yyvsp[(3) - (3)].sval); } }
     break;
 
-  case 89:
-#line 636 "sieve.y"
+  case 90:
+
+/* Line 1455 of yacc.c  */
+#line 645 "./sieve.y"
     { (yyval.nval) = ALL; }
     break;
 
-  case 90:
-#line 637 "sieve.y"
+  case 91:
+
+/* Line 1455 of yacc.c  */
+#line 646 "./sieve.y"
     { (yyval.nval) = LOCALPART; }
     break;
 
-  case 91:
-#line 638 "sieve.y"
+  case 92:
+
+/* Line 1455 of yacc.c  */
+#line 647 "./sieve.y"
     { (yyval.nval) = DOMAIN; }
     break;
 
-  case 92:
-#line 639 "sieve.y"
+  case 93:
+
+/* Line 1455 of yacc.c  */
+#line 648 "./sieve.y"
     { if (!parse_script->support.subaddress) {
 				     yyerror("subaddress MUST be enabled with \"require\"");
 				     YYERROR;
@@ -2546,8 +2751,10 @@
 				   (yyval.nval) = USER; }
     break;
 
-  case 93:
-#line 644 "sieve.y"
+  case 94:
+
+/* Line 1455 of yacc.c  */
+#line 653 "./sieve.y"
     { if (!parse_script->support.subaddress) {
 				     yyerror("subaddress MUST be enabled with \"require\"");
 				     YYERROR;
@@ -2555,23 +2762,31 @@
 				   (yyval.nval) = DETAIL; }
     break;
 
-  case 94:
-#line 650 "sieve.y"
+  case 95:
+
+/* Line 1455 of yacc.c  */
+#line 659 "./sieve.y"
     { (yyval.nval) = IS; }
     break;
 
-  case 95:
-#line 651 "sieve.y"
+  case 96:
+
+/* Line 1455 of yacc.c  */
+#line 660 "./sieve.y"
     { (yyval.nval) = CONTAINS; }
     break;
 
-  case 96:
-#line 652 "sieve.y"
+  case 97:
+
+/* Line 1455 of yacc.c  */
+#line 661 "./sieve.y"
     { (yyval.nval) = MATCHES; }
     break;
 
-  case 97:
-#line 653 "sieve.y"
+  case 98:
+
+/* Line 1455 of yacc.c  */
+#line 662 "./sieve.y"
     { if (!parse_script->support.regex) {
 				     yyerror("regex MUST be enabled with \"require\"");
 				     YYERROR;
@@ -2579,8 +2794,10 @@
 				   (yyval.nval) = REGEX; }
     break;
 
-  case 98:
-#line 660 "sieve.y"
+  case 99:
+
+/* Line 1455 of yacc.c  */
+#line 669 "./sieve.y"
     { if (!parse_script->support.relational) {
 				     yyerror("relational MUST be enabled with \"require\"");
 				     YYERROR;
@@ -2588,8 +2805,10 @@
 				   (yyval.nval) = COUNT; }
     break;
 
-  case 99:
-#line 665 "sieve.y"
+  case 100:
+
+/* Line 1455 of yacc.c  */
+#line 674 "./sieve.y"
     { if (!parse_script->support.relational) {
 				     yyerror("relational MUST be enabled with \"require\"");
 				     YYERROR;
@@ -2597,23 +2816,31 @@
 				   (yyval.nval) = VALUE; }
     break;
 
-  case 100:
-#line 673 "sieve.y"
+  case 101:
+
+/* Line 1455 of yacc.c  */
+#line 682 "./sieve.y"
     { (yyval.nval) = OVER; }
     break;
 
-  case 101:
-#line 674 "sieve.y"
+  case 102:
+
+/* Line 1455 of yacc.c  */
+#line 683 "./sieve.y"
     { (yyval.nval) = UNDER; }
     break;
 
-  case 102:
-#line 677 "sieve.y"
+  case 103:
+
+/* Line 1455 of yacc.c  */
+#line 686 "./sieve.y"
     { (yyval.nval) = 0; }
     break;
 
-  case 103:
-#line 678 "sieve.y"
+  case 104:
+
+/* Line 1455 of yacc.c  */
+#line 687 "./sieve.y"
     { if (!parse_script->support.copy) {
 				     yyerror("copy MUST be enabled with \"require\"");
 	                             YYERROR;
@@ -2621,24 +2848,31 @@
 				   (yyval.nval) = COPY; }
     break;
 
-  case 104:
-#line 685 "sieve.y"
+  case 105:
+
+/* Line 1455 of yacc.c  */
+#line 694 "./sieve.y"
     { (yyval.testl) = (yyvsp[(2) - (3)].testl); }
     break;
 
-  case 105:
-#line 688 "sieve.y"
+  case 106:
+
+/* Line 1455 of yacc.c  */
+#line 697 "./sieve.y"
     { (yyval.testl) = new_testlist((yyvsp[(1) - (1)].test), NULL); }
     break;
 
-  case 106:
-#line 689 "sieve.y"
+  case 107:
+
+/* Line 1455 of yacc.c  */
+#line 698 "./sieve.y"
     { (yyval.testl) = new_testlist((yyvsp[(1) - (3)].test), (yyvsp[(3) - (3)].testl)); }
     break;
 
 
-/* Line 1267 of yacc.c.  */
-#line 2642 "y.tab.c"
+
+/* Line 1455 of yacc.c  */
+#line 2876 "y.tab.c"
       default: break;
     }
   YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);
@@ -2649,7 +2883,6 @@
 
   *++yyvsp = yyval;
 
-
   /* Now `shift' the result of the reduction.  Determine what state
      that goes to, based on the state we popped back to and the rule
      number reduced by.  */
@@ -2714,7 +2947,7 @@
 
   if (yyerrstatus == 3)
     {
-      /* If just tried and failed to reuse look-ahead token after an
+      /* If just tried and failed to reuse lookahead token after an
 	 error, discard it.  */
 
       if (yychar <= YYEOF)
@@ -2731,7 +2964,7 @@
 	}
     }
 
-  /* Else will try to reuse look-ahead token after shifting the error
+  /* Else will try to reuse lookahead token after shifting the error
      token.  */
   goto yyerrlab1;
 
@@ -2788,9 +3021,6 @@
       YY_STACK_PRINT (yyss, yyssp);
     }
 
-  if (yyn == YYFINAL)
-    YYACCEPT;
-
   *++yyvsp = yylval;
 
 
@@ -2815,7 +3045,7 @@
   yyresult = 1;
   goto yyreturn;
 
-#ifndef yyoverflow
+#if !defined(yyoverflow) || YYERROR_VERBOSE
 /*-------------------------------------------------.
 | yyexhaustedlab -- memory exhaustion comes here.  |
 `-------------------------------------------------*/
@@ -2826,7 +3056,7 @@
 #endif
 
 yyreturn:
-  if (yychar != YYEOF && yychar != YYEMPTY)
+  if (yychar != YYEMPTY)
      yydestruct ("Cleanup: discarding lookahead",
 		 yytoken, &yylval);
   /* Do not reclaim the symbols of the rule which action triggered
@@ -2852,7 +3082,9 @@
 }
 
 
-#line 692 "sieve.y"
+
+/* Line 1675 of yacc.c  */
+#line 701 "./sieve.y"
 
 commandlist_t *sieve_parse(sieve_script_t *script, FILE *f)
 {
