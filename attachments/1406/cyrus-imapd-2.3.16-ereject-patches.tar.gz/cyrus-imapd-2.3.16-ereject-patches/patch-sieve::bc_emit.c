--- sieve/bc_emit.c.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/bc_emit.c	2011-01-20 17:48:43.000000000 +0000
@@ -537,6 +537,7 @@
 	    break;
 
 	case B_REJECT:
+        case B_EREJECT:
 	    /*just a string*/
 	    len = bc->data[codep++].len;
 	    if(write_int(fd,len) == -1)
