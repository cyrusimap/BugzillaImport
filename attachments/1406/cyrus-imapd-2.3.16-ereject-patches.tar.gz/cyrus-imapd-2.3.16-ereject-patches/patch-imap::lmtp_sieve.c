--- imap/lmtp_sieve.c.ORIG	2009-03-31 05:11:18.000000000 +0100
+++ imap/lmtp_sieve.c	2011-01-21 11:15:59.000000000 +0000
@@ -460,6 +460,19 @@
     }
 }
 
+static int sieve_ereject(void *ac, 
+			void *ic __attribute__((unused)), 
+			void *sc, void *mc, const char **errmsg)
+{
+    sieve_ereject_context_t *rc = (sieve_ereject_context_t *) ac;
+    script_data_t *sd = (script_data_t *) sc;
+    deliver_data_t *dd = (deliver_data_t *) mc;
+	
+    dd->status_msg = xstrdup(rc->msg);
+
+    return SIEVE_EREJECT;
+}
+
 static int sieve_fileinto(void *ac, 
 			  void *ic __attribute__((unused)),
 			  void *sc, 
@@ -737,6 +750,11 @@
 	syslog(LOG_ERR, "sieve_register_reject() returns %d\n", res);
 	fatal("sieve_register_reject()", EC_SOFTWARE);
     }
+    res = sieve_register_ereject(interp, &sieve_ereject);
+    if (res != SIEVE_OK) {
+	syslog(LOG_ERR, "sieve_register_ereject() returns %d\n", res);
+	fatal("sieve_register_ereject()", EC_SOFTWARE);
+    }
     res = sieve_register_fileinto(interp, &sieve_fileinto);
     if (res != SIEVE_OK) {
 	syslog(LOG_ERR, "sieve_register_fileinto() returns %d\n", res);
