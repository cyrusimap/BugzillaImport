--- imap/lmtpd.h.ORIG	2008-03-24 17:09:17.000000000 +0000
+++ imap/lmtpd.h	2011-01-20 19:25:25.000000000 +0000
@@ -68,6 +68,8 @@
 
     char *authuser;		/* user who submitted message */
     struct auth_state *authstate;
+
+    char *status_msg;		/* custom error message */
 } deliver_data_t;
 
 /* forward declarations */
