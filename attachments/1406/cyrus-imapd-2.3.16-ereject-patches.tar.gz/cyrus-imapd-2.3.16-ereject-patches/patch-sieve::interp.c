--- sieve/interp.c.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/interp.c	2011-01-20 17:36:36.000000000 +0000
@@ -74,7 +74,7 @@
 	return SIEVE_NOMEM;
     }
 
-    i->redirect = i->discard = i->reject = i->fileinto = i->keep = NULL;
+    i->redirect = i->discard = i->reject = i->ereject = i->fileinto = i->keep = NULL;
     i->getsize = NULL;
     i->getheader = NULL;
     i->getenvelope = NULL;
@@ -111,6 +111,9 @@
 	if (i->reject &&
 	    (config_sieve_extensions & IMAP_ENUM_SIEVE_EXTENSIONS_REJECT))
 	    strlcat(extensions, " reject", sizeof(extensions));
+	if (i->ereject &&
+	    (config_sieve_extensions & IMAP_ENUM_SIEVE_EXTENSIONS_EREJECT))
+	    strlcat(extensions, " ereject", sizeof(extensions));
 	if (i->vacation &&
 	    (config_sieve_extensions & IMAP_ENUM_SIEVE_EXTENSIONS_VACATION))
 	    strlcat(extensions, " vacation", sizeof(extensions));
@@ -179,6 +182,13 @@
     return SIEVE_OK;
 }
 
+int sieve_register_ereject(sieve_interp_t *interp, sieve_callback *f)
+{
+    interp->ereject = f;
+
+    return SIEVE_OK;
+}
+
 int sieve_register_fileinto(sieve_interp_t *interp, sieve_callback *f)
 {
     interp->fileinto = f;
