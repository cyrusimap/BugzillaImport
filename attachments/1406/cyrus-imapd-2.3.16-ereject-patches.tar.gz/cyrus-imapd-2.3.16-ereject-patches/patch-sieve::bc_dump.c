--- sieve/bc_dump.c.ORIG	2008-03-24 20:08:46.000000000 +0000
+++ sieve/bc_dump.c	2011-01-20 17:41:25.000000000 +0000
@@ -229,6 +229,11 @@
 		   d->data[i+1].len,d->data[i+2].str);
 	    i+=2;
 	    break;
+	case B_EREJECT:
+	    printf("%d: EREJECT {%d}%s\n",i,
+		   d->data[i+1].len,d->data[i+2].str);
+	    i+=2;
+	    break;
 	case B_IF:
 	    if (d->data[i+3].jump== -1)
 	    {
