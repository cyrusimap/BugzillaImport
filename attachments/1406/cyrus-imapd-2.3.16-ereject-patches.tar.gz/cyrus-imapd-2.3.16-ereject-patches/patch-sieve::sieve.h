--- sieve/sieve.h.ORIG	2009-12-21 13:17:55.000000000 +0000
+++ sieve/sieve.h	2011-01-20 19:19:47.000000000 +0000
@@ -1,24 +1,23 @@
-/* A Bison parser, made by GNU Bison 2.3.  */
 
-/* Skeleton interface for Bison's Yacc-like parsers in C
+/* A Bison parser, made by GNU Bison 2.4.1.  */
 
-   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
+/* Skeleton interface for Bison's Yacc-like parsers in C
+   
+      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
    Free Software Foundation, Inc.
-
-   This program is free software; you can redistribute it and/or modify
+   
+   This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
-   the Free Software Foundation; either version 2, or (at your option)
-   any later version.
-
+   the Free Software Foundation, either version 3 of the License, or
+   (at your option) any later version.
+   
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
-
+   
    You should have received a copy of the GNU General Public License
-   along with this program; if not, write to the Free Software
-   Foundation, Inc., 51 Franklin Street, Fifth Floor,
-   Boston, MA 02110-1301, USA.  */
+   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */
 
 /* As a special exception, you may create a larger work that contains
    part or all of the Bison parser skeleton and distribute that work
@@ -29,10 +28,11 @@
    special exception, which will cause the skeleton and the resulting
    Bison output files to be licensed under the GNU General Public
    License without this special exception.
-
+   
    This special exception was added by the Free Software Foundation in
    version 2.2 of Bison.  */
 
+
 /* Tokens.  */
 #ifndef YYTOKENTYPE
 # define YYTOKENTYPE
@@ -52,66 +52,67 @@
      DISCARD = 268,
      VACATION = 269,
      REQUIRE = 270,
-     SETFLAG = 271,
-     ADDFLAG = 272,
-     REMOVEFLAG = 273,
-     MARK = 274,
-     UNMARK = 275,
-     NOTIFY = 276,
-     DENOTIFY = 277,
-     ANYOF = 278,
-     ALLOF = 279,
-     EXISTS = 280,
-     SFALSE = 281,
-     STRUE = 282,
-     HEADER = 283,
-     NOT = 284,
-     SIZE = 285,
-     ADDRESS = 286,
-     ENVELOPE = 287,
-     BODY = 288,
-     COMPARATOR = 289,
-     IS = 290,
-     CONTAINS = 291,
-     MATCHES = 292,
-     REGEX = 293,
-     COUNT = 294,
-     VALUE = 295,
-     OVER = 296,
-     UNDER = 297,
-     GT = 298,
-     GE = 299,
-     LT = 300,
-     LE = 301,
-     EQ = 302,
-     NE = 303,
-     ALL = 304,
-     LOCALPART = 305,
-     DOMAIN = 306,
-     USER = 307,
-     DETAIL = 308,
-     RAW = 309,
-     TEXT = 310,
-     CONTENT = 311,
-     DAYS = 312,
-     ADDRESSES = 313,
-     SUBJECT = 314,
-     FROM = 315,
-     HANDLE = 316,
-     MIME = 317,
-     METHOD = 318,
-     ID = 319,
-     OPTIONS = 320,
-     LOW = 321,
-     NORMAL = 322,
-     HIGH = 323,
-     ANY = 324,
-     MESSAGE = 325,
-     INCLUDE = 326,
-     PERSONAL = 327,
-     GLOBAL = 328,
-     RETURN = 329,
-     COPY = 330
+     EREJCT = 271,
+     SETFLAG = 272,
+     ADDFLAG = 273,
+     REMOVEFLAG = 274,
+     MARK = 275,
+     UNMARK = 276,
+     NOTIFY = 277,
+     DENOTIFY = 278,
+     ANYOF = 279,
+     ALLOF = 280,
+     EXISTS = 281,
+     SFALSE = 282,
+     STRUE = 283,
+     HEADER = 284,
+     NOT = 285,
+     SIZE = 286,
+     ADDRESS = 287,
+     ENVELOPE = 288,
+     BODY = 289,
+     COMPARATOR = 290,
+     IS = 291,
+     CONTAINS = 292,
+     MATCHES = 293,
+     REGEX = 294,
+     COUNT = 295,
+     VALUE = 296,
+     OVER = 297,
+     UNDER = 298,
+     GT = 299,
+     GE = 300,
+     LT = 301,
+     LE = 302,
+     EQ = 303,
+     NE = 304,
+     ALL = 305,
+     LOCALPART = 306,
+     DOMAIN = 307,
+     USER = 308,
+     DETAIL = 309,
+     RAW = 310,
+     TEXT = 311,
+     CONTENT = 312,
+     DAYS = 313,
+     ADDRESSES = 314,
+     SUBJECT = 315,
+     FROM = 316,
+     HANDLE = 317,
+     MIME = 318,
+     METHOD = 319,
+     ID = 320,
+     OPTIONS = 321,
+     LOW = 322,
+     NORMAL = 323,
+     HIGH = 324,
+     ANY = 325,
+     MESSAGE = 326,
+     INCLUDE = 327,
+     PERSONAL = 328,
+     GLOBAL = 329,
+     RETURN = 330,
+     COPY = 331
    };
 #endif
 /* Tokens.  */
@@ -128,74 +129,78 @@
 #define DISCARD 268
 #define VACATION 269
 #define REQUIRE 270
-#define SETFLAG 271
-#define ADDFLAG 272
-#define REMOVEFLAG 273
-#define MARK 274
-#define UNMARK 275
-#define NOTIFY 276
-#define DENOTIFY 277
-#define ANYOF 278
-#define ALLOF 279
-#define EXISTS 280
-#define SFALSE 281
-#define STRUE 282
-#define HEADER 283
-#define NOT 284
-#define SIZE 285
-#define ADDRESS 286
-#define ENVELOPE 287
-#define BODY 288
-#define COMPARATOR 289
-#define IS 290
-#define CONTAINS 291
-#define MATCHES 292
-#define REGEX 293
-#define COUNT 294
-#define VALUE 295
-#define OVER 296
-#define UNDER 297
-#define GT 298
-#define GE 299
-#define LT 300
-#define LE 301
-#define EQ 302
-#define NE 303
-#define ALL 304
-#define LOCALPART 305
-#define DOMAIN 306
-#define USER 307
-#define DETAIL 308
-#define RAW 309
-#define TEXT 310
-#define CONTENT 311
-#define DAYS 312
-#define ADDRESSES 313
-#define SUBJECT 314
-#define FROM 315
-#define HANDLE 316
-#define MIME 317
-#define METHOD 318
-#define ID 319
-#define OPTIONS 320
-#define LOW 321
-#define NORMAL 322
-#define HIGH 323
-#define ANY 324
-#define MESSAGE 325
-#define INCLUDE 326
-#define PERSONAL 327
-#define GLOBAL 328
-#define RETURN 329
-#define COPY 330
+#define EREJCT 271
+#define SETFLAG 272
+#define ADDFLAG 273
+#define REMOVEFLAG 274
+#define MARK 275
+#define UNMARK 276
+#define NOTIFY 277
+#define DENOTIFY 278
+#define ANYOF 279
+#define ALLOF 280
+#define EXISTS 281
+#define SFALSE 282
+#define STRUE 283
+#define HEADER 284
+#define NOT 285
+#define SIZE 286
+#define ADDRESS 287
+#define ENVELOPE 288
+#define BODY 289
+#define COMPARATOR 290
+#define IS 291
+#define CONTAINS 292
+#define MATCHES 293
+#define REGEX 294
+#define COUNT 295
+#define VALUE 296
+#define OVER 297
+#define UNDER 298
+#define GT 299
+#define GE 300
+#define LT 301
+#define LE 302
+#define EQ 303
+#define NE 304
+#define ALL 305
+#define LOCALPART 306
+#define DOMAIN 307
+#define USER 308
+#define DETAIL 309
+#define RAW 310
+#define TEXT 311
+#define CONTENT 312
+#define DAYS 313
+#define ADDRESSES 314
+#define SUBJECT 315
+#define FROM 316
+#define HANDLE 317
+#define MIME 318
+#define METHOD 319
+#define ID 320
+#define OPTIONS 321
+#define LOW 322
+#define NORMAL 323
+#define HIGH 324
+#define ANY 325
+#define MESSAGE 326
+#define INCLUDE 327
+#define PERSONAL 328
+#define GLOBAL 329
+#define RETURN 330
+#define COPY 331
 
 
 
 
 #if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
 typedef union YYSTYPE
-#line 168 "sieve.y"
 {
+
+/* Line 1676 of yacc.c  */
+#line 168 "./sieve.y"
+
     int nval;
     char *sval;
     stringlist_t *sl;
@@ -208,14 +213,17 @@
     struct btags *btag;
     struct ntags *ntag;
     struct dtags *dtag;
-}
-/* Line 1489 of yacc.c.  */
-#line 214 "y.tab.h"
-	YYSTYPE;
+
+
+
+/* Line 1676 of yacc.c  */
+#line 221 "y.tab.h"
+} YYSTYPE;
+# define YYSTYPE_IS_TRIVIAL 1
 # define yystype YYSTYPE /* obsolescent; will be withdrawn */
 # define YYSTYPE_IS_DECLARED 1
-# define YYSTYPE_IS_TRIVIAL 1
 #endif
 
 extern YYSTYPE yylval;
 
+
