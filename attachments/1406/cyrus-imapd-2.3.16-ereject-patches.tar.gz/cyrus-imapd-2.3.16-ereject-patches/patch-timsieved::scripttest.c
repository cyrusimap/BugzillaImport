--- timsieved/scripttest.c.ORIG	2008-03-24 20:20:57.000000000 +0000
+++ timsieved/scripttest.c	2011-01-20 19:29:00.000000000 +0000
@@ -123,6 +123,11 @@
 	syslog(LOG_ERR, "sieve_register_reject() returns %d\n", res);
 	return TIMSIEVE_FAIL;
     }
+    res = sieve_register_ereject(interp, (sieve_callback *) &foo);
+    if (res != SIEVE_OK) {
+	syslog(LOG_ERR, "sieve_register_ereject() returns %d\n", res);
+	return TIMSIEVE_FAIL;
+    }
     res = sieve_register_fileinto(interp, (sieve_callback *) &foo);
     if (res != SIEVE_OK) {
 	syslog(LOG_ERR, "sieve_register_fileinto() returns %d\n", res);
