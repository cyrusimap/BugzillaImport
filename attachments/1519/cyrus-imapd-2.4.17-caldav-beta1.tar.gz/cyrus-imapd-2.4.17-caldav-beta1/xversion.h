/* Release cyrus-imapd-2.4.17-caldav-beta1 */
#define _CYRUS_VERSION "v2.4.17-caldav-beta1"
#define CYRUS_GITVERSION "bd236f6c 2013-05-08"
