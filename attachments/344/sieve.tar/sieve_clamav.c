/* COPYRIGHT
 * Copyright (c) 2002-2005 Igor Brezac
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY IGOR BREZAC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL IGOR BREZAC OR
 * ITS EMPLOYEES OR AGENTS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 * END COPYRIGHT */

/* $Id$ */

#include <config.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <syslog.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>

#include "append.h"
#include "auth.h"
#include "duplicate.h"
#include "exitcodes.h"
#include "global.h"
#include "lmtp_sieve.h"
#include "lmtpengine.h"
#include "lmtpstats.h"
#include "sieve_interface.h"
#include "prot.h"
#include "util.h"
#include "version.h"
#include "xmalloc.h"

#ifdef HAVE_CLAMAV

#include <clamav.h>

typedef struct clamav_ctx {
	struct cl_node *root;
	struct cl_limits limits;
	char *dbdir;
} clamav_ctx;

static int clamav_init()
{
	clamav_ctx *c, tmp;
	int ret, no=0;

	memset(&tmp, 0, sizeof(tmp));

	tmp.dbdir = (char *)config_getstring(IMAPOPT_SIEVE_CLAMAV_BACKEND_DBDIR);
	if (!tmp.dbdir)
		tmp.dbdir = (char *)cl_retdbdir();

	ret = cl_loaddbdir(tmp.dbdir, &(tmp.root), &no);
	if (ret) {
		syslog(LOG_ERR, "clamav error cl_loaddbdir: %s", cl_perror(ret));
		return SIEVE_FAIL;
	}

	ret = cl_build(tmp.root);
	if (ret) {
		syslog(LOG_ERR, "clamav database initialization error: %s", cl_strerror(ret));;
		cl_free(tmp.root);
		return SIEVE_FAIL;
	}

	tmp.limits.maxfiles = config_getint(IMAPOPT_SIEVE_CLAMAV_BACKEND_MAXFILES);
	tmp.limits.maxfilesize = config_getint(IMAPOPT_SIEVE_CLAMAV_BACKEND_MAXFILESIZE);
	tmp.limits.maxreclevel = config_getint(IMAPOPT_SIEVE_CLAMAV_BACKEND_MAXRECLEVEL);
	tmp.limits.maxratio = config_getint(IMAPOPT_SIEVE_CLAMAV_BACKEND_MAXRATIO);
	tmp.limits.archivememlim = config_getswitch(IMAPOPT_SIEVE_CLAMAV_BACKEND_ARCHIVEMEMLIM);

	c = xmalloc(sizeof(clamav_ctx));
	if (!c) {
		syslog(LOG_ERR, "cannot allocate memeory");;
		cl_free(tmp.root);
		return SIEVE_FAIL;
	}
	*c = tmp;
	sieve_clamav.context = c;
	
	return SIEVE_OK;
}

static int clamav_scan(
    void *context, 
    message_data_t *m,
    char **val)
{
	int fd;
	int ret, size = 0;
	const char *virname;
	clamav_ctx *c = context;

	*val = "0";

	if (!c || !c->root) {
		syslog(LOG_ERR, "clamav environment not initialized");;
		return SIEVE_FAIL;
	}

	prot_rewind(m->data);
	ret = cl_scandesc(m->data->fd, &virname, &size, c->root, &(c->limits), CL_SCAN_STDOPT);
	if (ret == CL_VIRUS) {
		*val = "10";
		syslog(LOG_NOTICE, "clamav detected virus (%s)", virname);
		return SIEVE_OK;
	}

	if (ret != CL_CLEAN) {
		syslog(LOG_NOTICE, "clamav error in virus detection: %s", cl_perror(ret));
		return SIEVE_OK;
	}

	*val = "1";
	return SIEVE_OK;
}

static void clamav_free(
    char *context)
{
	clamav_ctx *c = (clamav_ctx *)context;

	if (c) {
		if (c->root)
			cl_free(c->root);
		free(c);
	}

	return;
} 

sieve_backend_t sieve_clamav = 
{
    "clamav",
    NULL,
    &clamav_init,
    &clamav_scan,
    &clamav_free 
};

#else /* HAVE_CLAMAV */

static int clamav_scan(
    void *context __attribute__((unused)), 
    message_data_t *m __attribute__ ((unused)),
    char **val)
{
	syslog(LOG_ERR, "clamav sieve backend not compiled-in");
	return SIEVE_FAIL;
}

sieve_backend_t sieve_clamav = 
{
    "clamav",
    NULL,
    NULL,
    &clamav_scan,
    NULL 
};

#endif
